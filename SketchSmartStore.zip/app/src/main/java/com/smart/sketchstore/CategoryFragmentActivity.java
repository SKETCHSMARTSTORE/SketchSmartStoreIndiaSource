package com.smart.sketchstore;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.github.angads25.filepicker.*;
import com.google.firebase.FirebaseApp;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;

public class CategoryFragmentActivity extends Fragment {
	
	private ScrollView linear_navigation4;
	private TextView textview1;
	private LinearLayout linear_category;
	private LinearLayout b1;
	private LinearLayout b2;
	private LinearLayout b3;
	private LinearLayout b4;
	private LinearLayout b5;
	private LinearLayout b6;
	private LinearLayout b7;
	private LinearLayout b8;
	private LinearLayout b9;
	private LinearLayout b10;
	private LinearLayout b11;
	private LinearLayout b12;
	private LinearLayout b13;
	private LinearLayout b14;
	private LinearLayout b15;
	private LinearLayout b16;
	private ImageView i1;
	private TextView t2;
	private ImageView i2;
	private TextView t3;
	private ImageView i3;
	private TextView t4;
	private ImageView i4;
	private TextView t5;
	private ImageView i5;
	private TextView t6;
	private ImageView i6;
	private TextView t7;
	private ImageView i7;
	private TextView t8;
	private ImageView i8;
	private TextView t9;
	private ImageView i9;
	private TextView t10;
	private ImageView i10;
	private TextView t11;
	private ImageView i11;
	private TextView t12;
	private ImageView i12;
	private TextView t13;
	private ImageView i13;
	private TextView t14;
	private ImageView i14;
	private TextView t15;
	private ImageView i15;
	private TextView t16;
	private ImageView i16;
	private TextView t17;
	
	private Intent intent = new Intent();
	
	@NonNull
	@Override
	public View onCreateView(@NonNull LayoutInflater _inflater, @Nullable ViewGroup _container, @Nullable Bundle _savedInstanceState) {
		View _view = _inflater.inflate(R.layout.category_fragment, _container, false);
		initialize(_savedInstanceState, _view);
		FirebaseApp.initializeApp(getContext());
		initializeLogic();
		return _view;
	}
	
	private void initialize(Bundle _savedInstanceState, View _view) {
		linear_navigation4 = _view.findViewById(R.id.linear_navigation4);
		textview1 = _view.findViewById(R.id.textview1);
		linear_category = _view.findViewById(R.id.linear_category);
		b1 = _view.findViewById(R.id.b1);
		b2 = _view.findViewById(R.id.b2);
		b3 = _view.findViewById(R.id.b3);
		b4 = _view.findViewById(R.id.b4);
		b5 = _view.findViewById(R.id.b5);
		b6 = _view.findViewById(R.id.b6);
		b7 = _view.findViewById(R.id.b7);
		b8 = _view.findViewById(R.id.b8);
		b9 = _view.findViewById(R.id.b9);
		b10 = _view.findViewById(R.id.b10);
		b11 = _view.findViewById(R.id.b11);
		b12 = _view.findViewById(R.id.b12);
		b13 = _view.findViewById(R.id.b13);
		b14 = _view.findViewById(R.id.b14);
		b15 = _view.findViewById(R.id.b15);
		b16 = _view.findViewById(R.id.b16);
		i1 = _view.findViewById(R.id.i1);
		t2 = _view.findViewById(R.id.t2);
		i2 = _view.findViewById(R.id.i2);
		t3 = _view.findViewById(R.id.t3);
		i3 = _view.findViewById(R.id.i3);
		t4 = _view.findViewById(R.id.t4);
		i4 = _view.findViewById(R.id.i4);
		t5 = _view.findViewById(R.id.t5);
		i5 = _view.findViewById(R.id.i5);
		t6 = _view.findViewById(R.id.t6);
		i6 = _view.findViewById(R.id.i6);
		t7 = _view.findViewById(R.id.t7);
		i7 = _view.findViewById(R.id.i7);
		t8 = _view.findViewById(R.id.t8);
		i8 = _view.findViewById(R.id.i8);
		t9 = _view.findViewById(R.id.t9);
		i9 = _view.findViewById(R.id.i9);
		t10 = _view.findViewById(R.id.t10);
		i10 = _view.findViewById(R.id.i10);
		t11 = _view.findViewById(R.id.t11);
		i11 = _view.findViewById(R.id.i11);
		t12 = _view.findViewById(R.id.t12);
		i12 = _view.findViewById(R.id.i12);
		t13 = _view.findViewById(R.id.t13);
		i13 = _view.findViewById(R.id.i13);
		t14 = _view.findViewById(R.id.t14);
		i14 = _view.findViewById(R.id.i14);
		t15 = _view.findViewById(R.id.t15);
		i15 = _view.findViewById(R.id.i15);
		t16 = _view.findViewById(R.id.t16);
		i16 = _view.findViewById(R.id.i16);
		t17 = _view.findViewById(R.id.t17);
	}
	
	private void initializeLogic() {
		b1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t2.getText().toString());
				startActivity(intent);
				}
		});
		b2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t3.getText().toString());
				startActivity(intent);
				}
		});
		b3.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t4.getText().toString());
				startActivity(intent);
				}
		});
		b4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t5.getText().toString());
				startActivity(intent);
				}
		});
		b5.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t6.getText().toString());
				startActivity(intent);
				}
		});
		b6.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t7.getText().toString());
				startActivity(intent);
				}
		});
		b7.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t8.getText().toString());
				startActivity(intent);
				}
		});
		b8.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t9.getText().toString());
				startActivity(intent);
				}
		});
		b9.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t10.getText().toString());
				startActivity(intent);
				}
		});
		b10.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t11.getText().toString());
				startActivity(intent);
				}
		});
		b11.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t12.getText().toString());
				startActivity(intent);
				}
		});
		b12.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t13.getText().toString());
				startActivity(intent);
				}
		});
		b13.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t14.getText().toString());
				startActivity(intent);
				}
		});
		b14.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t15.getText().toString());
				startActivity(intent);
				}
		});
		b15.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t16.getText().toString());
				startActivity(intent);
				}
		});
		b16.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						intent.setClass(getContext().getApplicationContext(), CategoryViewActivity.class);
				intent.putExtra("title", t17.getText().toString());
				startActivity(intent);
				}
		});
	}
	
}