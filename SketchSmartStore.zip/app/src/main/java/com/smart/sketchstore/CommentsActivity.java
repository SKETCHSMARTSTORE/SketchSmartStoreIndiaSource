package com.smart.sketchstore;

import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.github.angads25.filepicker.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

public class CommentsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private String comment_key = "";
	private String key = "";
	private String uid = "";
	private String token = "";
	private String serverKey = "";
	private HashMap<String, Object> map = new HashMap<>();
	private String name = "";
	private HashMap<String, Object> notification_map = new HashMap<>();
	private String comments_key = "";
	private String project_nmae = "";
	private String avater = "";
	
	private ArrayList<HashMap<String, Object>> listmap = new ArrayList<>();
	
	private LinearLayout linear1;
	private LinearLayout linear2;
	private ListView listview1;
	private EditText edittext1;
	private ImageView imageview1;
	
	
	private OnCompleteListener notification_onCompleteListener;
	private DatabaseReference comments = _firebase.getReference("comments");
	private ChildEventListener _comments_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private Calendar cal = Calendar.getInstance();
	private DatabaseReference notifications = _firebase.getReference("notifications");
	private ChildEventListener _notifications_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private RequestNetwork requestNetwork;
	private RequestNetwork.RequestListener _requestNetwork_request_listener;
	private Menu mymenu;
	private PopupMenu mypopup;
	private AlertDialog.Builder comedit;
	private AlertDialog tools;
	private AlertDialog.Builder comdelete;
	private Intent intent = new Intent();
	private AlertDialog secondtools;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.comments);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		listview1 = findViewById(R.id.listview1);
		edittext1 = findViewById(R.id.edittext1);
		imageview1 = findViewById(R.id.imageview1);
		auth = FirebaseAuth.getInstance();
		requestNetwork = new RequestNetwork(this);
		comedit = new AlertDialog.Builder(this);
		comdelete = new AlertDialog.Builder(this);
		
		listview1.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
			@Override
			public boolean onItemLongClick(AdapterView<?> _param1, View _param2, int _param3, long _param4) {
				final int _position = _param3;
				if (listmap.get((int)_position).get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					final AlertDialog tools = new AlertDialog.Builder(CommentsActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.menu,null); tools.setView(inflate);
					tools.setTitle("More Options");
					LinearLayout lin = (LinearLayout)inflate.findViewById(R.id.linear1);
					LinearLayout lin1 = (LinearLayout)inflate.findViewById(R.id.linear2);
					LinearLayout lin2 = (LinearLayout)inflate.findViewById(R.id.linear3);
					LinearLayout lin3 = (LinearLayout)inflate.findViewById(R.id.linear4);
					LinearLayout lin5 = (LinearLayout)inflate.findViewById(R.id.linear5);
					TextView txt = (TextView)inflate.findViewById(R.id.textview1);
					TextView txt1 = (TextView)inflate.findViewById(R.id.textview2);
					TextView txt2 = (TextView)inflate.findViewById(R.id.textview3);
					TextView txt3 = (TextView)inflate.findViewById(R.id.textview4);
					ImageView img = (ImageView)inflate.findViewById(R.id.imageview1);
					ImageView img1 = (ImageView)inflate.findViewById(R.id.imageview2);
					ImageView img2 = (ImageView)inflate.findViewById(R.id.imageview3);
					ImageView img3 = (ImageView)inflate.findViewById(R.id.imageview4);
					lin1.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									comdelete.setTitle("you are delete this message?");
							comdelete.setMessage("are you sure to delete this message?");
							comdelete.setPositiveButton("delete", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									comments.child(listmap.get((int)_position).get("key").toString()).removeValue();
								}
							});
							comdelete.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									
								}
							});
							comdelete.create().show();
							}
					});
					lin2.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									comedit.setTitle("are you edit this message?");
							comdelete.setMessage("i can agree this message?");
							
							LinearLayout mylayout = new LinearLayout(CommentsActivity.this);
							
							LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
							
							mylayout.setLayoutParams(params); mylayout.setOrientation(LinearLayout.VERTICAL);
							
							final EditText myedittext = new EditText(CommentsActivity.this);
							myedittext.setLayoutParams(new LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT));
							 
							mylayout.addView(myedittext);
							comedit.setView(mylayout);
							myedittext.setText(listmap.get((int)_position).get("comment").toString());
							
							comedit.setPositiveButton("edit", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									map = new HashMap<>();
									map.put("comment", myedittext.getText().toString());
									map.put("key", listmap.get((int)_position).get("key").toString());
									comments.child(listmap.get((int)_position).get("key").toString()).updateChildren(map);
									map.clear();
									SketchwareUtil.showMessage(getApplicationContext(), "comment edit success");
								}
							});
							comedit.setNegativeButton("cancel", new DialogInterface.OnClickListener() {
								@Override
								public void onClick(DialogInterface _dialog, int _which) {
									
								}
							});
							comedit.create().show();
							}
					});
					lin3.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", listmap.get((int)_position).get("comment").toString()));
							SketchwareUtil.showMessage(getApplicationContext(), "your comment copied in clipboard");
							}
					});
					lin5.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									intent.setClass(getApplicationContext(), ProfileActivity.class);
							intent.putExtra("uid", listmap.get((int)_position).get("uid").toString());
							startActivity(intent);
							}
					});
					tools.setCancelable(true);
					tools.show();
				}
				else {
					final AlertDialog secondtools = new AlertDialog.Builder(CommentsActivity.this).create();
					View inflate = getLayoutInflater().inflate(R.layout.menu,null); secondtools.setView(inflate);
					secondtools.setTitle("More Options");
					LinearLayout lin = (LinearLayout)inflate.findViewById(R.id.linear1);
					LinearLayout lin1 = (LinearLayout)inflate.findViewById(R.id.linear2);
					LinearLayout lin2 = (LinearLayout)inflate.findViewById(R.id.linear3);
					LinearLayout lin3 = (LinearLayout)inflate.findViewById(R.id.linear4);
					LinearLayout lin5 = (LinearLayout)inflate.findViewById(R.id.linear5);
					TextView txt = (TextView)inflate.findViewById(R.id.textview1);
					TextView txt1 = (TextView)inflate.findViewById(R.id.textview2);
					TextView txt2 = (TextView)inflate.findViewById(R.id.textview3);
					TextView txt3 = (TextView)inflate.findViewById(R.id.textview4);
					ImageView img = (ImageView)inflate.findViewById(R.id.imageview1);
					ImageView img1 = (ImageView)inflate.findViewById(R.id.imageview2);
					ImageView img2 = (ImageView)inflate.findViewById(R.id.imageview3);
					ImageView img3 = (ImageView)inflate.findViewById(R.id.imageview4);
					lin1.setVisibility(View.GONE);
					lin2.setVisibility(View.GONE);
					lin3.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									((ClipboardManager) getSystemService(getApplicationContext().CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("clipboard", listmap.get((int)_position).get("comment").toString()));
							SketchwareUtil.showMessage(getApplicationContext(), "your comment copied in clipboard");
							}
					});
					lin5.setOnClickListener(new View.OnClickListener() {
							@Override
							public void onClick(View _view) {
									intent.setClass(getApplicationContext(), ProfileActivity.class);
							intent.putExtra("uid", listmap.get((int)_position).get("uid").toString());
							startActivity(intent);
							}
					});
					secondtools.setCancelable(true);
					secondtools.show();
				}
				return true;
			}
		});
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (edittext1.getText().toString().equals("")) {
					((EditText)edittext1).setError("enter comments after send message...");
				}
				else {
					_sendFCMNotification(serverKey, name, edittext1.getText().toString(), "null", "null", token);
					comments_key = comments.push().getKey();
					map = new HashMap<>();
					map.put("comment", edittext1.getText().toString());
					map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("name", name);
					map.put("avater", avater);
					map.put("key", comments_key);
					map.put("time", new SimpleDateFormat("dd:MM:yyyy hh:mm").format(cal.getTime()));
					comments.child(comments_key).updateChildren(map);
					map.clear();
					notification_map = new HashMap<>();
					notification_map.put("notification", name.concat("  ".concat(project_nmae.concat("  ".concat("comments on")))));
					notification_map.put("comment", edittext1.getText().toString());
					notification_map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					notification_map.put("name", name);
					notification_map.put("avater", avater);
					notification_map.put("time", new SimpleDateFormat("dd:MM:yyyy hh:mm").format(cal.getTime()));
					notifications.push().updateChildren(notification_map);
					notification_map.clear();
					SketchwareUtil.showMessage(getApplicationContext(), "your comment has been sended...");
					edittext1.setText("");
				}
			}
		});
		
		notification_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_comments_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				comments.addListenerForSingleValueEvent(new ValueEventListener() {
					@Override
					public void onDataChange(DataSnapshot _dataSnapshot) {
						listmap = new ArrayList<>();
						try {
							GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
							for (DataSnapshot _data : _dataSnapshot.getChildren()) {
								HashMap<String, Object> _map = _data.getValue(_ind);
								listmap.add(_map);
							}
						}
						catch (Exception _e) {
							_e.printStackTrace();
						}
						listview1.setAdapter(new Listview1Adapter(listmap));
						((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
					}
					@Override
					public void onCancelled(DatabaseError _databaseError) {
					}
				});
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		comments.addChildEventListener(_comments_child_listener);
		
		_notifications_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		notifications.addChildEventListener(_notifications_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("avater")) {
						avater = _childValue.get("avater").toString();
					}
					if (_childValue.containsKey("name")) {
						name = _childValue.get("name").toString();
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("avater")) {
						avater = _childValue.get("avater").toString();
					}
					if (_childValue.containsKey("name")) {
						name = _childValue.get("name").toString();
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_requestNetwork_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		key = getIntent().getStringExtra("key");
		uid = getIntent().getStringExtra("uid");
		token = getIntent().getStringExtra("token");
		project_nmae = getIntent().getStringExtra("name");
		comments.removeEventListener(_comments_child_listener);
		comment_key = "comments_key/".concat(key);
		comments =
		_firebase.getReference(comment_key);
		comments.addChildEventListener(_comments_child_listener);
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			_subscribeFCMTopic("all");
			serverKey = "AAAAQMZlKP8:APA91bH0JgFNGHaZyrivaYwcwPrf9xw5buKcDBu3MdJcgHJrEDp7OwBXudrU4a3NMRBwOMkdAXZqPMxAHg91IDH5Myvk9bnZjNudSryvlYCA42hOAlZvAFo3rnVxDxi43I7mx5YU4Rt0";
			_getDeviceFCMToken();
		}
		else {
			
		}
	}
	
	public void _getDeviceFCMToken() {
		FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(@NonNull Task<InstanceIdResult> task) {
				if (task.isSuccessful()) {
					token = task.getResult().getToken();
					
					
					
					
					
					// here my_token is textview
					
					
					
					
					
				} else {
					
					
					
				}}});
	}
	
	
	public void _subscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().subscribeToTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						SketchwareUtil.showMessage(getApplicationContext(), "Subscribed Successfully");
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Subscribe");
					}}});
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _unsubscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().unsubscribeFromTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						SketchwareUtil.showMessage(getApplicationContext(), "Unsubscribed Successfully");
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Unsubscribe");
					}}});
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _sendFCMNotification(final String _key, final String _title, final String _content, final String _imageUrl, final String _topic, final String _token) {
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			HashMap<String, Object> requestHeader = new HashMap<>();
			
			HashMap<String, Object> notificationBody = new HashMap<>();
			
			HashMap<String, Object> requestBody = new HashMap<>();
			requestHeader = new HashMap<>();
			requestHeader.put("Authorization", "key=".concat(_key));
			requestHeader.put("Content-Type", "application/json");
			
			notificationBody = new HashMap<>();
			notificationBody.put("title", _title);
			notificationBody.put("body", _content);
			notificationBody.put("image", _imageUrl);
			
			requestBody = new HashMap<>();
			if (!_topic.equals("null")) {
				requestBody.put("to", "/topics/".concat(_topic));
			} else {
				requestBody.put("to", _token);
			}
			requestBody.put("notification", notificationBody);
			requestNetwork.setHeaders(requestHeader);
			requestNetwork.setParams(requestBody, RequestNetworkController.REQUEST_BODY);
			requestNetwork.startRequestNetwork(RequestNetworkController.POST, "https://fcm.googleapis.com/fcm/send", "", _requestNetwork_request_listener);
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "No Internet Connection");
		}
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.comment, null);
			}
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView time = _view.findViewById(R.id.time);
			final de.hdodenhof.circleimageview.CircleImageView avater = _view.findViewById(R.id.avater);
			final TextView name = _view.findViewById(R.id.name);
			final TextView message = _view.findViewById(R.id.message);
			
			if (_data.get((int)_position).containsKey("comment")) {
				message.setText(_data.get((int)_position).get("comment").toString());
			}
			if (_data.get((int)_position).containsKey("time")) {
				time.setText(_data.get((int)_position).get("time").toString());
			}
			if (_data.get((int)_position).containsKey("name")) {
				name.setText(_data.get((int)_position).get("name").toString());
			}
			if (_data.get((int)_position).containsKey("avater")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("avater").toString())).into(avater);
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}