package com.smart.sketchstore;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentStatePagerAdapter;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager.widget.ViewPager.OnAdapterChangeListener;
import androidx.viewpager.widget.ViewPager.OnPageChangeListener;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.github.angads25.filepicker.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.bottomnavigation.BottomNavigationView.OnNavigationItemSelectedListener;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import de.hdodenhof.circleimageview.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;

public class HomeActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private Toolbar _toolbar;
	private AppBarLayout _app_bar;
	private CoordinatorLayout _coordinator;
	private DrawerLayout _drawer;
	private boolean doubleTap = false;
	private HashMap<String, Object> map = new HashMap<>();
	private String this_version = "";
	
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private ImageView menu;
	private TextView textview1;
	private CircleImageView profile_image;
	private ViewPager viewpager1;
	private BottomNavigationView bottomnavigation1;
	private ScrollView _drawer_vscroll1;
	private LinearLayout _drawer_linear1;
	private LinearLayout _drawer_linear2;
	private LinearLayout _drawer_linear3;
	private LinearLayout _drawer_profile_goto;
	private LinearLayout _drawer_java_codes_layout;
	private LinearLayout _drawer_Custom_Blocks;
	private LinearLayout _drawer_linear23;
	private LinearLayout _drawer_linear25;
	private LinearLayout _drawer_moreblock;
	private LinearLayout _drawer_linear30;
	private CircleImageView _drawer_avater;
	private TextView _drawer_name;
	private TextView _drawer_email;
	private LinearLayout _drawer_linear4;
	private TextView _drawer_textview1;
	private ImageView _drawer_imageview1;
	private LinearLayout _drawer_linear6;
	private TextView _drawer_textview2;
	private CircleImageView _drawer_profile_avater;
	private LinearLayout _drawer_linear9;
	private TextView _drawer_textview3;
	private ImageView _drawer_imageview2;
	private LinearLayout _drawer_linear13;
	private TextView _drawer_textview5;
	private ImageView _drawer_imageview4;
	private LinearLayout _drawer_linear24;
	private TextView _drawer_textview8;
	private ImageView _drawer_imageview6;
	private LinearLayout _drawer_linear26;
	private TextView _drawer_textview9;
	private ImageView _drawer_imageview7;
	private LinearLayout _drawer_linear29;
	private TextView _drawer_textview10;
	private ImageView _drawer_imageview8;
	private LinearLayout _drawer_linear31;
	private TextView _drawer_textview11;
	private ImageView _drawer_imageview9;
	
	private FragFragmentAdapter frag;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private TimerTask timer;
	private Intent intent = new Intent();
	private DatabaseReference update = _firebase.getReference("update");
	private ChildEventListener _update_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.home);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_app_bar = findViewById(R.id._app_bar);
		_coordinator = findViewById(R.id._coordinator);
		_toolbar = findViewById(R.id._toolbar);
		setSupportActionBar(_toolbar);
		getSupportActionBar().setDisplayHomeAsUpEnabled(true);
		getSupportActionBar().setHomeButtonEnabled(true);
		_toolbar.setNavigationOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _v) {
				onBackPressed();
			}
		});
		_drawer = findViewById(R.id._drawer);
		ActionBarDrawerToggle _toggle = new ActionBarDrawerToggle(HomeActivity.this, _drawer, _toolbar, R.string.app_name, R.string.app_name);
		_drawer.addDrawerListener(_toggle);
		_toggle.syncState();
		
		LinearLayout _nav_view = findViewById(R.id._nav_view);
		
		linear1 = findViewById(R.id.linear1);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		menu = findViewById(R.id.menu);
		textview1 = findViewById(R.id.textview1);
		profile_image = findViewById(R.id.profile_image);
		viewpager1 = findViewById(R.id.viewpager1);
		bottomnavigation1 = findViewById(R.id.bottomnavigation1);
		_drawer_vscroll1 = _nav_view.findViewById(R.id.vscroll1);
		_drawer_linear1 = _nav_view.findViewById(R.id.linear1);
		_drawer_linear2 = _nav_view.findViewById(R.id.linear2);
		_drawer_linear3 = _nav_view.findViewById(R.id.linear3);
		_drawer_profile_goto = _nav_view.findViewById(R.id.profile_goto);
		_drawer_java_codes_layout = _nav_view.findViewById(R.id.java_codes_layout);
		_drawer_Custom_Blocks = _nav_view.findViewById(R.id.Custom_Blocks);
		_drawer_linear23 = _nav_view.findViewById(R.id.linear23);
		_drawer_linear25 = _nav_view.findViewById(R.id.linear25);
		_drawer_moreblock = _nav_view.findViewById(R.id.moreblock);
		_drawer_linear30 = _nav_view.findViewById(R.id.linear30);
		_drawer_avater = _nav_view.findViewById(R.id.avater);
		_drawer_name = _nav_view.findViewById(R.id.name);
		_drawer_email = _nav_view.findViewById(R.id.email);
		_drawer_linear4 = _nav_view.findViewById(R.id.linear4);
		_drawer_textview1 = _nav_view.findViewById(R.id.textview1);
		_drawer_imageview1 = _nav_view.findViewById(R.id.imageview1);
		_drawer_linear6 = _nav_view.findViewById(R.id.linear6);
		_drawer_textview2 = _nav_view.findViewById(R.id.textview2);
		_drawer_profile_avater = _nav_view.findViewById(R.id.profile_avater);
		_drawer_linear9 = _nav_view.findViewById(R.id.linear9);
		_drawer_textview3 = _nav_view.findViewById(R.id.textview3);
		_drawer_imageview2 = _nav_view.findViewById(R.id.imageview2);
		_drawer_linear13 = _nav_view.findViewById(R.id.linear13);
		_drawer_textview5 = _nav_view.findViewById(R.id.textview5);
		_drawer_imageview4 = _nav_view.findViewById(R.id.imageview4);
		_drawer_linear24 = _nav_view.findViewById(R.id.linear24);
		_drawer_textview8 = _nav_view.findViewById(R.id.textview8);
		_drawer_imageview6 = _nav_view.findViewById(R.id.imageview6);
		_drawer_linear26 = _nav_view.findViewById(R.id.linear26);
		_drawer_textview9 = _nav_view.findViewById(R.id.textview9);
		_drawer_imageview7 = _nav_view.findViewById(R.id.imageview7);
		_drawer_linear29 = _nav_view.findViewById(R.id.linear29);
		_drawer_textview10 = _nav_view.findViewById(R.id.textview10);
		_drawer_imageview8 = _nav_view.findViewById(R.id.imageview8);
		_drawer_linear31 = _nav_view.findViewById(R.id.linear31);
		_drawer_textview11 = _nav_view.findViewById(R.id.textview11);
		_drawer_imageview9 = _nav_view.findViewById(R.id.imageview9);
		frag = new FragFragmentAdapter(getApplicationContext(), getSupportFragmentManager());
		auth = FirebaseAuth.getInstance();
		
		menu.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_drawer.openDrawer(GravityCompat.START);
			}
		});
		
		textview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SearchActivity.class);
				startActivity(intent);
			}
		});
		
		profile_image.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ProfileActivity.class);
				intent.putExtra("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				intent.putExtra("mode", "user");
				startActivity(intent);
			}
		});
		
		viewpager1.addOnPageChangeListener(new ViewPager.OnPageChangeListener() {
			@Override
			public void onPageScrolled(int _position, float _positionOffset, int _positionOffsetPixels) {
				
			}
			
			@Override
			public void onPageSelected(int _position) {
				bottomnavigation1.getMenu().getItem(_position).setChecked(true);
			}
			
			@Override
			public void onPageScrollStateChanged(int _scrollState) {
				
			}
		});
		
		bottomnavigation1.setOnNavigationItemSelectedListener(new BottomNavigationView.OnNavigationItemSelectedListener() {
			@Override
			public boolean onNavigationItemSelected(MenuItem item) {
				final int _itemId = item.getItemId();
				viewpager1.setCurrentItem((int)_itemId);
				return true;
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("avater")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(profile_image);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(_drawer_avater);
					}
					if (_childValue.containsKey("name")) {
						_drawer_name.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("email")) {
						_drawer_email.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("ban")) {
						if (_childValue.get("ban").toString().equals("true")) {
							intent.setClass(getApplicationContext(), BannedActivity.class);
							startActivity(intent);
						}
						else {
							
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("avater")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(profile_image);
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(_drawer_avater);
					}
					if (_childValue.containsKey("name")) {
						_drawer_name.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("email")) {
						_drawer_email.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("ban")) {
						if (_childValue.get("ban").toString().equals("true")) {
							intent.setClass(getApplicationContext(), BannedActivity.class);
							startActivity(intent);
						}
						else {
							
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_update_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("app")) {
					if (Double.parseDouble(this_version) < Double.parseDouble(_childValue.get("v").toString())) {
						intent.setClass(getApplicationContext(), UpdateAvailableActivity.class);
						startActivity(intent);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals("app")) {
					if (Double.parseDouble(this_version) < Double.parseDouble(_childValue.get("v").toString())) {
						intent.setClass(getApplicationContext(), UpdateAvailableActivity.class);
						startActivity(intent);
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		update.addChildEventListener(_update_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		getSupportActionBar().hide();
		this_version = "1.1";
		_ripple(menu);
		_ripple(profile_image);
		_ripple(textview1);
		frag.setTabCount(4);
		viewpager1.setAdapter(frag);
		bottomnavigation1.getMenu().add(0, 0, 0, "home").setIcon(R.drawable.ic_home_black);
		bottomnavigation1.getMenu().add(0, 1, 0, "all projects").setIcon(R.drawable.ic_list_black);
		bottomnavigation1.getMenu().add(0, 2, 0, "notifications").setIcon(R.drawable.ic_notifications_black);
		bottomnavigation1.getMenu().add(0, 3, 0, "category").setIcon(R.drawable.ic_apps_black);
		_drawer_linear3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), UploadProjectActivity.class);
				startActivity(intent);
			}
		});
		_drawer_java_codes_layout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), JavaCodesActivity.class);
				startActivity(intent);
			}
		});
		_drawer_linear23.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), SketchwareManagerActivity.class);
				startActivity(intent);
			}
		});
		_drawer_linear25.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), XmlsActivity.class);
				startActivity(intent);
			}
		});
		_drawer_profile_goto.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ProfileActivity.class);
				intent.putExtra("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
				intent.putExtra("mode", "user");
				startActivity(intent);
			}
		});
		_drawer_Custom_Blocks.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), CustomBlocksActivity.class);
				startActivity(intent);
			}
		});
		_drawer_moreblock.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), MoreBlocksActivity.class);
				startActivity(intent);
			}
		});
		_drawer_linear30.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), AboutAppActivity.class);
				startActivity(intent);
			}
		});
	}
	
	public class FragFragmentAdapter extends FragmentStatePagerAdapter {
		// This class is deprecated, you should migrate to ViewPager2:
		// https://developer.android.com/reference/androidx/viewpager2/widget/ViewPager2
		Context context;
		int tabCount;
		
		public FragFragmentAdapter(Context context, FragmentManager manager) {
			super(manager);
			this.context = context;
		}
		
		public void setTabCount(int tabCount) {
			this.tabCount = tabCount;
		}
		
		@Override
		public int getCount() {
			return tabCount;
		}
		
		@Override
		public CharSequence getPageTitle(int _position) {
			
			return null;
		}
		
		@Override
		public Fragment getItem(int _position) {
			if (_position == 0) {
				return new HomeProjectsFragmentActivity();
			}
			if (_position == 1) {
				return new AllProjectsFragmentActivity();
			}
			if (_position == 2) {
				return new NotificationsFragmentActivity();
			}
			if (_position == 3) {
				return new CategoryFragmentActivity();
			}
			return null;
		}
	}
	
	@Override
	public void onBackPressed() {
		if (doubleTap) {
			finishAffinity();
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Double Tap to Exit");
			doubleTap = true;
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							doubleTap = false;
						}
					});
				}
			};
			_timer.schedule(timer, (int)(2000));
		}
	}
	public void _ripple(final View _view) {
		
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
		android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
		int backgroundResource = typedArray.getResourceId(0, 0); _view.setBackgroundResource(backgroundResource);
		_view.setClickable(true);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}