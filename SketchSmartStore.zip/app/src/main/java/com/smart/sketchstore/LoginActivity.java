package com.smart.sketchstore;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.ClipData;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.github.angads25.filepicker.*;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;
import pl.droidsonroids.gif.GifImageView;
import com.shobhitpuri.custombuttons.GoogleSignInButton;

public class LoginActivity extends AppCompatActivity {
	
	public final int REQ_CD_GLOGIN = 101;
	public final int REQ_CD_PERMISSION = 102;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private boolean pass_hide_show = false;
	private boolean doubleTap = false;
	GoogleSignInOptions options;
	AuthCredential credential;
	FirebaseUser FirebaseUser;
	private HashMap<String, Object> map = new HashMap<>();
	GoogleSignInAccount account;
	private boolean emailVerified = false;
	
	private LinearLayout linear4;
	private LinearLayout linear5;
	private ScrollView vscroll1;
	private LinearLayout linear7;
	private GifImageView Gift;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout imnotrebot;
	private TextView textview9;
	private LinearLayout policy;
	private LinearLayout login_not_an_account_layout;
	private LinearLayout login_btn;
	private LinearLayout SignIn_btn;
	private GoogleSignInButton Google_SignIn_Button;
	private LinearLayout signup_an_alredy_an_account_layout;
	private TextInputLayout email_textinputlayout;
	private EditText email_et;
	private TextInputLayout password_textinputlayout;
	private EditText password_et;
	private TextView code;
	private TextInputLayout add_code;
	private EditText verification;
	private LinearLayout linear13;
	private LinearLayout linear14;
	private TextView textview4;
	private TextView textview5;
	private TextView textview6;
	private TextView signup_now_layout;
	private TextView signup_txt;
	private TextView login_txt;
	private TextView signin_txt;
	private TextView textview2;
	private TextView textview3;
	private TextView textview8;
	private TextView textview7;
	
	private Intent intent = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private TimerTask timer;
	private GoogleSignInClient glogin;
	private Calendar cal = Calendar.getInstance();
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private Intent permission = new Intent(Intent.ACTION_GET_CONTENT);
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.login);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear4 = findViewById(R.id.linear4);
		linear5 = findViewById(R.id.linear5);
		vscroll1 = findViewById(R.id.vscroll1);
		linear7 = findViewById(R.id.linear7);
		Gift = findViewById(R.id.Gift);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		imnotrebot = findViewById(R.id.imnotrebot);
		textview9 = findViewById(R.id.textview9);
		policy = findViewById(R.id.policy);
		login_not_an_account_layout = findViewById(R.id.login_not_an_account_layout);
		login_btn = findViewById(R.id.login_btn);
		SignIn_btn = findViewById(R.id.SignIn_btn);
		Google_SignIn_Button = findViewById(R.id.Google_SignIn_Button);
		signup_an_alredy_an_account_layout = findViewById(R.id.signup_an_alredy_an_account_layout);
		email_textinputlayout = findViewById(R.id.email_textinputlayout);
		email_et = findViewById(R.id.email_et);
		password_textinputlayout = findViewById(R.id.password_textinputlayout);
		password_et = findViewById(R.id.password_et);
		code = findViewById(R.id.code);
		add_code = findViewById(R.id.add_code);
		verification = findViewById(R.id.verification);
		linear13 = findViewById(R.id.linear13);
		linear14 = findViewById(R.id.linear14);
		textview4 = findViewById(R.id.textview4);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		signup_now_layout = findViewById(R.id.signup_now_layout);
		signup_txt = findViewById(R.id.signup_txt);
		login_txt = findViewById(R.id.login_txt);
		signin_txt = findViewById(R.id.signin_txt);
		textview2 = findViewById(R.id.textview2);
		textview3 = findViewById(R.id.textview3);
		textview8 = findViewById(R.id.textview8);
		textview7 = findViewById(R.id.textview7);
		auth = FirebaseAuth.getInstance();
		permission.setType("*/*");
		permission.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		textview9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setClass(getApplicationContext(), ForgetPasswordActivity.class);
				startActivity(intent);
			}
		});
		
		login_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try{
					if (email_et.getText().toString().equals("") && (password_et.getText().toString().equals("") && verification.getText().toString().equals(""))) {
						if (email_et.getText().toString().equals("")) {
							email_textinputlayout.setError("empty email...");
						}
						else {
							if (password_et.getText().toString().equals("")) {
								password_textinputlayout.setError("empty password...");
							}
							else {
								if (code.getText().toString().equals(verification.getText().toString())) {
									if (code.getText().toString().equals(verification.getText().toString())) {
										auth.signInWithEmailAndPassword(email_et.getText().toString(), password_et.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
										SketchwareUtil.showMessage(getApplicationContext(), "please wait...");
									}
									else {
										
									}
								}
								else {
									verification.setText("");
									add_code.setError("im not robot is failed your verification code is wrong...");
								}
							}
						}
					}
					else {
						if (email_et.getText().toString().equals("")) {
							email_textinputlayout.setError("empty email...");
						}
						else {
							if (password_et.getText().toString().equals("")) {
								password_textinputlayout.setError("empty password...");
							}
							else {
								if (code.getText().toString().equals(verification.getText().toString())) {
									if (code.getText().toString().equals(verification.getText().toString())) {
										auth.signInWithEmailAndPassword(email_et.getText().toString(), password_et.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_sign_in_listener);
										SketchwareUtil.showMessage(getApplicationContext(), "please wait...");
									}
									else {
										
									}
								}
								else {
									verification.setText("");
									add_code.setError("im not robot is failed your verification code is wrong...");
								}
							}
						}
					}
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "an error occurred...");
				}
			}
		});
		
		SignIn_btn.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				try{
					if (email_et.getText().toString().equals("") && (password_et.getText().toString().equals("") && verification.getText().toString().equals(""))) {
						if (email_et.getText().toString().equals("")) {
							email_textinputlayout.setError("empty email...");
						}
						else {
							if (password_et.getText().toString().equals("")) {
								password_textinputlayout.setError("empty password...");
							}
							else {
								if (code.getText().toString().equals(verification.getText().toString())) {
									if (code.getText().toString().equals(verification.getText().toString())) {
										auth.createUserWithEmailAndPassword(email_et.getText().toString(), password_et.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
										SketchwareUtil.showMessage(getApplicationContext(), "please wait...");
									}
									else {
										
									}
								}
								else {
									verification.setText("");
									add_code.setError("im not robot is failed your verification code is wrong...");
								}
							}
						}
					}
					else {
						if (email_et.getText().toString().equals("")) {
							email_textinputlayout.setError("empty email...");
						}
						else {
							if (password_et.getText().toString().equals("")) {
								password_textinputlayout.setError("empty password...");
							}
							else {
								if (code.getText().toString().equals(verification.getText().toString())) {
									if (code.getText().toString().equals(verification.getText().toString())) {
										auth.createUserWithEmailAndPassword(email_et.getText().toString(), password_et.getText().toString()).addOnCompleteListener(LoginActivity.this, _auth_create_user_listener);
										SketchwareUtil.showMessage(getApplicationContext(), "please wait...");
									}
									else {
										
									}
								}
								else {
									verification.setText("");
									add_code.setError("im not robot is failed your verification code is wrong...");
								}
							}
						}
					}
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), "an error occurred...");
				}
			}
		});
		
		Google_SignIn_Button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				Intent signInIntent = glogin.getSignInIntent();
				
				startActivityForResult(signInIntent, REQ_CD_GLOGIN);
			}
		});
		
		verification.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		textview5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://www.youtube.com/@SketchSmartStoreIndia"));
				startActivity(intent);
			}
		});
		
		signup_txt.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				signup_an_alredy_an_account_layout.setVisibility(View.VISIBLE);
				SignIn_btn.setVisibility(View.VISIBLE);
				login_not_an_account_layout.setVisibility(View.GONE);
				login_btn.setVisibility(View.GONE);
			}
		});
		
		textview3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				signup_an_alredy_an_account_layout.setVisibility(View.GONE);
				SignIn_btn.setVisibility(View.GONE);
				login_not_an_account_layout.setVisibility(View.VISIBLE);
				login_btn.setVisibility(View.VISIBLE);
			}
		});
		
		textview8.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://www.youtube.com/@SketchSmartStoreIndia"));
				startActivity(intent);
			}
		});
		
		textview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				intent.setAction(Intent.ACTION_VIEW);
				intent.setData(Uri.parse("https://www.youtube.com/@SketchSmartStoreIndia"));
				startActivity(intent);
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					map = new HashMap<>();
					map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					map.put("name", "user".concat(String.valueOf((long)(SketchwareUtil.getRandom((int)(0), (int)(1000000))))));
					map.put("avater", "https://firebasestorage.googleapis.com/v0/b/uptime-store-5319f.appspot.com/o/images%20(2).jpeg?alt=media&token=eaf7cd8c-a4f6-49a2-9d3f-9bb596d4145b");
					map.put("date", new SimpleDateFormat("dd/MM/yyyy hh/mm/hs ms a").format(cal.getTime()));
					map.put("verification", "false");
					map.put("ban", "false");
					map.put("email", FirebaseAuth.getInstance().getCurrentUser().getEmail());
					map.put("about", "he there im use Sketch Smart Store!");
					users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					//code for verification link send on user email
					
					auth.getCurrentUser().sendEmailVerification() .addOnCompleteListener(new OnCompleteListener<Void>() {
						@Override
						public void onComplete(Task<Void> task) {
							if (task.isSuccessful()) {
								showMessage("Verification Link has been sent to your email !"); } else {
								showMessage ("Verification Link could not be sent !");}
						} });
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				if (_success) {
					emailVerified = auth.getCurrentUser().isEmailVerified();
					
					if (emailVerified) {
						intent.setClass(getApplicationContext(), UploadProfileActivity.class);
						startActivity(intent);
						SketchwareUtil.showMessage(getApplicationContext(), "Sign In Is Complete...");
					}
					else {
						SketchwareUtil.showMessage(getApplicationContext(), "Your Verification Code Is Send On Your Email...");
					}
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), _errorMessage);
				}
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		password_et.setTransformationMethod(android.text.method.PasswordTransformationMethod.getInstance());
		pass_hide_show = false;
		login_btn.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFF44336));
		SignIn_btn.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFF2196F3));
		GoogleSignInOptions options = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN).requestIdToken("278206425343-3a06h7g5vm3uo4m98li9uq7vgd6g3llf.apps.googleusercontent.com").requestEmail().build();
		glogin = GoogleSignIn.getClient(this, options);
		auth = FirebaseAuth.getInstance();
		code.setText(String.valueOf((long)(SketchwareUtil.getRandom((int)(123), (int)(456)))));
		email_et.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		password_et.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		code.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		verification.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		signup_now_layout.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		signup_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		login_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		signin_txt.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		signup_an_alredy_an_account_layout.setVisibility(View.GONE);
		SignIn_btn.setVisibility(View.GONE);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_GLOGIN:
			if (_resultCode == Activity.RESULT_OK) {
				Task<GoogleSignInAccount> _task = GoogleSignIn.getSignedInAccountFromIntent(_data);
				
				try{
					
					_firebaseAuthWithGoogle(account);
				}catch(Exception e){
					SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		if (doubleTap) {
			finishAffinity();
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Double Tap to Exit");
			doubleTap = true;
			timer = new TimerTask() {
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
						@Override
						public void run() {
							doubleTap = false;
						}
					});
				}
			};
			_timer.schedule(timer, (int)(2000));
		}
	}
	public void _firebaseAuthWithGoogle(final GoogleSignInAccount _account) {
		
		
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}