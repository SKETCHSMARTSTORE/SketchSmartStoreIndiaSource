package com.smart.sketchstore;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.Intent;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.*;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.RecyclerView.Adapter;
import androidx.recyclerview.widget.RecyclerView.ViewHolder;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.github.angads25.filepicker.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import de.hdodenhof.circleimageview.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;

public class ProfileActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	private String key = "";
	private double posts = 0;
	private String like_key = "";
	
	private ArrayList<HashMap<String, Object>> maplist = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> gridmap = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> gridmap3 = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear5;
	private LinearLayout linear2;
	private LinearLayout linear6;
	private LinearLayout linear10;
	private LinearLayout linear11;
	private LinearLayout linear12;
	private LinearLayout linear14;
	private LinearLayout linear18;
	private LinearLayout linear19;
	private ImageView imageview1;
	private TextView textview2;
	private ImageView sign_out;
	private LinearLayout linear21;
	private ImageView profile_edit;
	private LinearLayout linear20;
	private ImageView share_profile;
	private LinearLayout linear3;
	private LinearLayout linear4;
	private CircleImageView avater;
	private LinearLayout linear22;
	private ImageView verification;
	private TextView username;
	private TextView textview9;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private TextView textview3;
	private TextView projects_count;
	private TextView textview4;
	private TextView likes_count;
	private TextView textview5;
	private TextView downloadscount;
	private TextView textview6;
	private RecyclerView verified;
	private TextView textview7;
	private RecyclerView choice;
	private TextView textview8;
	private RecyclerView projects;
	
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private DatabaseReference data1 = _firebase.getReference("data1");
	private ChildEventListener _data1_child_listener;
	private Intent i = new Intent();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private AlertDialog actiondialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear5 = findViewById(R.id.linear5);
		linear2 = findViewById(R.id.linear2);
		linear6 = findViewById(R.id.linear6);
		linear10 = findViewById(R.id.linear10);
		linear11 = findViewById(R.id.linear11);
		linear12 = findViewById(R.id.linear12);
		linear14 = findViewById(R.id.linear14);
		linear18 = findViewById(R.id.linear18);
		linear19 = findViewById(R.id.linear19);
		imageview1 = findViewById(R.id.imageview1);
		textview2 = findViewById(R.id.textview2);
		sign_out = findViewById(R.id.sign_out);
		linear21 = findViewById(R.id.linear21);
		profile_edit = findViewById(R.id.profile_edit);
		linear20 = findViewById(R.id.linear20);
		share_profile = findViewById(R.id.share_profile);
		linear3 = findViewById(R.id.linear3);
		linear4 = findViewById(R.id.linear4);
		avater = findViewById(R.id.avater);
		linear22 = findViewById(R.id.linear22);
		verification = findViewById(R.id.verification);
		username = findViewById(R.id.username);
		textview9 = findViewById(R.id.textview9);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		textview3 = findViewById(R.id.textview3);
		projects_count = findViewById(R.id.projects_count);
		textview4 = findViewById(R.id.textview4);
		likes_count = findViewById(R.id.likes_count);
		textview5 = findViewById(R.id.textview5);
		downloadscount = findViewById(R.id.downloadscount);
		textview6 = findViewById(R.id.textview6);
		verified = findViewById(R.id.verified);
		textview7 = findViewById(R.id.textview7);
		choice = findViewById(R.id.choice);
		textview8 = findViewById(R.id.textview8);
		projects = findViewById(R.id.projects);
		auth = FirebaseAuth.getInstance();
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		sign_out.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_action_dialog("you are sign out?", "you can sign out this account?", "cancel", "sign out", "");
			}
		});
		
		profile_edit.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ProfileEditActivity.class);
				startActivity(i);
			}
		});
		
		share_profile.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				SketchwareUtil.showMessage(getApplicationContext(), "please subscribe to smart India gaming channel and complete 1000 subscribe to make website api to app.");
			}
		});
		
		projects.addOnScrollListener(new RecyclerView.OnScrollListener() {
			@Override
			public void onScrollStateChanged(RecyclerView recyclerView, int _scrollState) {
				super.onScrollStateChanged(recyclerView, _scrollState);
				
			}
			
			@Override
			public void onScrolled(RecyclerView recyclerView, int _offsetX, int _offsetY) {
				super.onScrolled(recyclerView, _offsetX, _offsetY);
				
			}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					if (getIntent().getStringExtra("uid").equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						sign_out.setVisibility(View.VISIBLE);
						profile_edit.setVisibility(View.VISIBLE);
						share_profile.setVisibility(View.GONE);
						if (_childValue.containsKey("likes")) {
							likes_count.setText(_childValue.get("likes").toString());
						}
						if (_childValue.containsKey("download")) {
							downloadscount.setText(_childValue.get("download").toString());
						}
						if (_childValue.containsKey("name")) {
							username.setText(_childValue.get("name").toString());
						}
						if (_childValue.containsKey("avater")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(avater);
						}
						if (_childValue.containsKey("about")) {
							textview9.setText(_childValue.get("about").toString());
						}
						if (_childValue.containsKey("verification")) {
							if (_childValue.get("verification").toString().equals("true")) {
								linear22.setVisibility(View.VISIBLE);
							}
							else {
								linear22.setVisibility(View.GONE);
							}
						}
					}
					else {
						if (_childValue.containsKey("likes")) {
							likes_count.setText(_childValue.get("likes").toString());
						}
						if (_childValue.containsKey("download")) {
							downloadscount.setText(_childValue.get("download").toString());
						}
						if (_childValue.containsKey("name")) {
							username.setText(_childValue.get("name").toString());
						}
						if (_childValue.containsKey("avater")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(avater);
						}
						if (_childValue.containsKey("about")) {
							textview9.setText(_childValue.get("about").toString());
						}
						if (_childValue.containsKey("verification")) {
							if (_childValue.get("verification").toString().equals("true")) {
								linear22.setVisibility(View.VISIBLE);
							}
							else {
								linear22.setVisibility(View.GONE);
							}
						}
						sign_out.setVisibility(View.GONE);
						profile_edit.setVisibility(View.GONE);
						share_profile.setVisibility(View.VISIBLE);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					if (getIntent().getStringExtra("uid").equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						sign_out.setVisibility(View.VISIBLE);
						profile_edit.setVisibility(View.VISIBLE);
						share_profile.setVisibility(View.GONE);
						if (_childValue.containsKey("likes")) {
							likes_count.setText(_childValue.get("likes").toString());
						}
						if (_childValue.containsKey("download")) {
							downloadscount.setText(_childValue.get("download").toString());
						}
						if (_childValue.containsKey("name")) {
							username.setText(_childValue.get("name").toString());
						}
						if (_childValue.containsKey("avater")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(avater);
						}
						if (_childValue.containsKey("about")) {
							textview9.setText(_childValue.get("about").toString());
						}
						if (_childValue.containsKey("verification")) {
							if (_childValue.get("verification").toString().equals("true")) {
								linear22.setVisibility(View.VISIBLE);
							}
							else {
								linear22.setVisibility(View.GONE);
							}
						}
					}
					else {
						if (_childValue.containsKey("likes")) {
							likes_count.setText(_childValue.get("likes").toString());
						}
						if (_childValue.containsKey("download")) {
							downloadscount.setText(_childValue.get("download").toString());
						}
						if (_childValue.containsKey("name")) {
							username.setText(_childValue.get("name").toString());
						}
						if (_childValue.containsKey("avater")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(avater);
						}
						if (_childValue.containsKey("about")) {
							textview9.setText(_childValue.get("about").toString());
						}
						if (_childValue.containsKey("verification")) {
							if (_childValue.get("verification").toString().equals("true")) {
								linear22.setVisibility(View.VISIBLE);
							}
							else {
								linear22.setVisibility(View.GONE);
							}
						}
						sign_out.setVisibility(View.GONE);
						profile_edit.setVisibility(View.GONE);
						share_profile.setVisibility(View.VISIBLE);
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_data1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().getStringExtra("mode").equals("user")) {
					if (_childValue.get("uid").toString().equals(getIntent().getStringExtra("uid"))) {
						maplist.add((int)0, _childValue);
					}
					projects.setAdapter(new ProjectsAdapter(maplist));
					projects_count.setText(String.valueOf((long)(maplist.size())));
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							gridmap.add((int)0, _childValue);
						}
						verified.setHasFixedSize(true);
						verified.setAdapter(new VerifiedAdapter(gridmap));
					}
					if (_childValue.containsKey("editor")) {
						if (_childValue.get("editor").toString().equals("true")) {
							gridmap3.add((int)0, _childValue);
						}
						choice.setHasFixedSize(true);
						choice.setAdapter(new ChoiceAdapter(gridmap3));
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().getStringExtra("mode").equals("user")) {
					if (_childValue.get("uid").toString().equals(getIntent().getStringExtra("uid"))) {
						maplist.add((int)0, _childValue);
					}
					projects.setAdapter(new ProjectsAdapter(maplist));
					projects_count.setText(String.valueOf((long)(maplist.size())));
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							gridmap.add((int)0, _childValue);
						}
						verified.setHasFixedSize(true);
						verified.setAdapter(new VerifiedAdapter(gridmap));
					}
					if (_childValue.containsKey("editor")) {
						if (_childValue.get("editor").toString().equals("true")) {
							gridmap3.add((int)0, _childValue);
						}
						choice.setHasFixedSize(true);
						choice.setAdapter(new ChoiceAdapter(gridmap3));
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data1.addChildEventListener(_data1_child_listener);
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		_ripple(sign_out);
		_ripple(profile_edit);
		_ripple(share_profile);
		verified.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		projects.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
		choice.setLayoutManager(new LinearLayoutManager(this,LinearLayoutManager.HORIZONTAL, false));
	}
	
	public void _ripple(final View _view) {
		
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
		android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
		int backgroundResource = typedArray.getResourceId(0, 0); _view.setBackgroundResource(backgroundResource);
		_view.setClickable(true);
	}
	
	
	public void _action_dialog(final String _titl, final String _desc, final String _button1, final String _button2, final String _mesg) {
		// mesg is waste
		final AlertDialog actiondialog = new AlertDialog.Builder(ProfileActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.sign_out,null); actiondialog.setView(inflate);
		LinearLayout lin = (LinearLayout)inflate.findViewById(R.id.linear1);
		pl.droidsonroids.gif.GifImageView lin2 = (pl.droidsonroids.gif.GifImageView)inflate.findViewById(R.id.linear2);
		LinearLayout lin3 = (LinearLayout)inflate.findViewById(R.id.linear3);
		LinearLayout lin4 = (LinearLayout)inflate.findViewById(R.id.linear4);
		LinearLayout lin5 = (LinearLayout)inflate.findViewById(R.id.linear5);
		TextView txt1 = (TextView)inflate.findViewById(R.id.textview);
		TextView txt2 = (TextView)inflate.findViewById(R.id.textview_message);
		TextView but1 = (TextView)inflate.findViewById(R.id.but1);
		TextView but2 = (TextView)inflate.findViewById(R.id.but2);
		lin.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)35, 0xFFFFFFFF));
		lin.setBackgroundColor(0xFFFFFFFF);
		lin3.setBackgroundColor(0xFFFFFFFF);
		lin4.setBackgroundColor(0xFFFFFFFF);
		lin5.setBackgroundColor(0xFFFFFFFF);
		txt1.setTextColor(0xFFF66555);
		txt1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		txt2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		but1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		but2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		txt2.setTextColor(0xFF3F51B6);
		but1.setTextColor(0xFF2196F3);
		but2.setTextColor(0xFFF44336);
		txt1.setText(_titl);
		txt2.setText(_desc);
		but1.setText(_button1);
		but2.setText(_button2);
		but1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						actiondialog.dismiss();
				}
		});
		but2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						FirebaseAuth.getInstance().signOut();
				i.setClass(getApplicationContext(), MainActivity.class);
				startActivity(i);
				SketchwareUtil.showMessage(getApplicationContext(), "sign out is successfully...");
				actiondialog.dismiss();
				}
		});
		actiondialog.setCancelable(true);
		actiondialog.show();
	}
	
	public class VerifiedAdapter extends RecyclerView.Adapter<VerifiedAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public VerifiedAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.home_cus, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView title = _view.findViewById(R.id.title);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView icon = _view.findViewById(R.id.icon);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView likes = _view.findViewById(R.id.likes);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView comments = _view.findViewById(R.id.comments);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("icon")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("icon").toString())).into(icon);
			}
			else {
				icon.setImageResource(R.drawable.android_icon);
			}
			if (_data.get((int)_position).containsKey("title")) {
				title.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("likes")) {
				likes.setText(_data.get((int)_position).get("likes").toString());
			}
			if (_data.get((int)_position).containsKey("comments")) {
				comments.setText(_data.get((int)_position).get("comments").toString());
			}
			title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensanis.ttf"), 0);
			likes.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensanis.ttf"), 0);
			comments.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensanis.ttf"), 0);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ProjectViewActivity.class);
					i.putExtra("uid", _data.get((int)_position).get("uid").toString());
					i.putExtra("key", _data.get((int)_position).get("key").toString());
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class ChoiceAdapter extends RecyclerView.Adapter<ChoiceAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ChoiceAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.editors, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final androidx.cardview.widget.CardView cardview2 = _view.findViewById(R.id.cardview2);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView title = _view.findViewById(R.id.title);
			final TextView catagory = _view.findViewById(R.id.catagory);
			final TextView size = _view.findViewById(R.id.size);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
			catagory.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/tajawal_medium.ttf"), 0);
			size.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ProjectViewActivity.class);
					i.putExtra("uid", _data.get((int)_position).get("uid").toString());
					i.putExtra("key", _data.get((int)_position).get("key").toString());
					startActivity(i);
				}
			});
			if (_data.get((int)_position).containsKey("size")) {
				size.setText(_data.get((int)_position).get("size").toString());
			}
			if (_data.get((int)_position).containsKey("title")) {
				title.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("catagory")) {
				catagory.setText(_data.get((int)_position).get("catagory").toString());
			}
			if (_data.get((int)_position).containsKey("sc1")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("sc1").toString())).into(imageview1);
			}
			if (_data.get((int)_position).containsKey("icon")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("icon").toString())).into(imageview2);
			}
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	public class ProjectsAdapter extends RecyclerView.Adapter<ProjectsAdapter.ViewHolder> {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public ProjectsAdapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
			LayoutInflater _inflater = getLayoutInflater();
			View _v = _inflater.inflate(R.layout.home_cus, null);
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_v.setLayoutParams(_lp);
			return new ViewHolder(_v);
		}
		
		@Override
		public void onBindViewHolder(ViewHolder _holder, final int _position) {
			View _view = _holder.itemView;
			
			final LinearLayout linear1 = _view.findViewById(R.id.linear1);
			final androidx.cardview.widget.CardView cardview1 = _view.findViewById(R.id.cardview1);
			final TextView title = _view.findViewById(R.id.title);
			final LinearLayout linear2 = _view.findViewById(R.id.linear2);
			final ImageView icon = _view.findViewById(R.id.icon);
			final ImageView imageview1 = _view.findViewById(R.id.imageview1);
			final TextView likes = _view.findViewById(R.id.likes);
			final ImageView imageview2 = _view.findViewById(R.id.imageview2);
			final TextView comments = _view.findViewById(R.id.comments);
			
			RecyclerView.LayoutParams _lp = new RecyclerView.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
			_view.setLayoutParams(_lp);
			if (_data.get((int)_position).containsKey("icon")) {
				Glide.with(getApplicationContext()).load(Uri.parse(_data.get((int)_position).get("icon").toString())).into(icon);
			}
			else {
				icon.setImageResource(R.drawable.android_icon);
			}
			if (_data.get((int)_position).containsKey("title")) {
				title.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("likes")) {
				likes.setText(_data.get((int)_position).get("likes").toString());
			}
			if (_data.get((int)_position).containsKey("comments")) {
				comments.setText(_data.get((int)_position).get("comments").toString());
			}
			title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensanis.ttf"), 0);
			likes.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensanis.ttf"), 0);
			comments.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/opensanis.ttf"), 0);
			linear1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
					i.setClass(getApplicationContext(), ProjectViewActivity.class);
					i.putExtra("uid", _data.get((int)_position).get("uid").toString());
					i.putExtra("key", _data.get((int)_position).get("key").toString());
					startActivity(i);
				}
			});
		}
		
		@Override
		public int getItemCount() {
			return _data.size();
		}
		
		public class ViewHolder extends RecyclerView.ViewHolder {
			public ViewHolder(View v) {
				super(v);
			}
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}