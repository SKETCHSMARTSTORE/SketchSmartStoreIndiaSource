package com.smart.sketchstore;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.github.angads25.filepicker.*;
import com.github.angads25.filepicker.controller.DialogSelectionListener ;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import de.hdodenhof.circleimageview.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.File;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;
import com.github.angads25.filepicker.controller.DialogSelectionListener ;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;

public class ProfileEditActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	private String imgpath = "";
	private String imgname = "";
	private String img = "";
	private String imggname = "";
	private String down = "";
	private double fp_avaver = 0;
	private double count = 0;
	
	private LinearLayout toolbar;
	private LinearLayout content_wrapper;
	private ImageView back_img;
	private TextView toolbar_title;
	private ImageView done_img;
	private RelativeLayout profile_relative;
	private TextView username_setted;
	private LinearLayout email_field;
	private LinearLayout username_field;
	private LinearLayout bio_field;
	private LinearLayout profile_wrapper;
	private LinearLayout choose_wrapper;
	private CircleImageView profile_image;
	private LinearLayout choose_layout;
	private ImageView choose_image;
	private TextView email_title;
	private EditText email_edittext;
	private LinearLayout email_base;
	private TextView email_error;
	private TextView username_title;
	private LinearLayout username_wrapper;
	private LinearLayout username_base;
	private TextView username_error;
	private TextView at_rate;
	private EditText username_edittext;
	private TextView bio_title;
	private EditText bio_edittext;
	private LinearLayout bio_base;
	private TextView bio_error;
	
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private Intent intent = new Intent();
	private SharedPreferences file;
	private StorageReference upavaver = _firebase_storage.getReference("avater");
	private OnCompleteListener<Uri> _upavaver_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _upavaver_download_success_listener;
	private OnSuccessListener _upavaver_delete_success_listener;
	private OnProgressListener _upavaver_upload_progress_listener;
	private OnProgressListener _upavaver_download_progress_listener;
	private OnFailureListener _upavaver_failure_listener;
	
	private FilePickerDialog fpd;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.profile_edit);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		toolbar = findViewById(R.id.toolbar);
		content_wrapper = findViewById(R.id.content_wrapper);
		back_img = findViewById(R.id.back_img);
		toolbar_title = findViewById(R.id.toolbar_title);
		done_img = findViewById(R.id.done_img);
		profile_relative = findViewById(R.id.profile_relative);
		username_setted = findViewById(R.id.username_setted);
		email_field = findViewById(R.id.email_field);
		username_field = findViewById(R.id.username_field);
		bio_field = findViewById(R.id.bio_field);
		profile_wrapper = findViewById(R.id.profile_wrapper);
		choose_wrapper = findViewById(R.id.choose_wrapper);
		profile_image = findViewById(R.id.profile_image);
		choose_layout = findViewById(R.id.choose_layout);
		choose_image = findViewById(R.id.choose_image);
		email_title = findViewById(R.id.email_title);
		email_edittext = findViewById(R.id.email_edittext);
		email_base = findViewById(R.id.email_base);
		email_error = findViewById(R.id.email_error);
		username_title = findViewById(R.id.username_title);
		username_wrapper = findViewById(R.id.username_wrapper);
		username_base = findViewById(R.id.username_base);
		username_error = findViewById(R.id.username_error);
		at_rate = findViewById(R.id.at_rate);
		username_edittext = findViewById(R.id.username_edittext);
		bio_title = findViewById(R.id.bio_title);
		bio_edittext = findViewById(R.id.bio_edittext);
		bio_base = findViewById(R.id.bio_base);
		bio_error = findViewById(R.id.bio_error);
		auth = FirebaseAuth.getInstance();
		file = getSharedPreferences("file", Activity.MODE_PRIVATE);
		
		back_img.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		done_img.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (img.equals("")) {
					com.google.android.material.snackbar.Snackbar.make(content_wrapper, "add profile avater...", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
						@Override
									public void onClick(View _view) {
											 
									}
					}).show();
				}
				else {
					if (count == 0) {
						com.google.android.material.snackbar.Snackbar.make(content_wrapper, "progressing...", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
							@Override
										public void onClick(View _view) {
												 
										}
						}).show();
					}
					else {
						_upload_successfully(down);
					}
				}
			}
		});
		
		choose_layout.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				DialogProperties fpdp = new DialogProperties();
				fpdp.selection_mode = DialogConfigs.SINGLE_MODE;
				fpdp.selection_type = DialogConfigs.FILE_SELECT;
				fpdp.root = new java.io.File(FileUtil.getExternalStorageDir());
				fpdp.error_dir = new java.io.File(FileUtil.getExternalStorageDir());
				fpdp.offset = new java.io.File(FileUtil.getExternalStorageDir());
				fpdp.extensions = new String[] {".png",".apng",".gif",".jpg",".jpeg"};
				fpd = new FilePickerDialog(ProfileEditActivity.this,fpdp);
				fpd.setTitle("pick image file");
				fpd.setPositiveBtnName("upload");
				fpd.setNegativeBtnName("cancel");
				fpd.setDialogSelectionListener(new DialogSelectionListener() {
					@Override public void onSelectedFilePaths(String[] files) {
						Glide.with(getApplicationContext()).load(Uri.parse(file.getString("picked_path", ""))).into(profile_image);
						img = Arrays.asList(files).get((int) 0).toString();
						imggname = Uri.parse(Arrays.asList(files).get((int) 0).toString()).getLastPathSegment();
						upavaver.child(imggname).putFile(Uri.fromFile(new File(img))).addOnFailureListener(_upavaver_failure_listener).addOnProgressListener(_upavaver_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
							@Override
							public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
								return upavaver.child(imggname).getDownloadUrl();
							}}).addOnCompleteListener(_upavaver_upload_success_listener);
					} 
				});
				fpd.show();
			}
		});
		
		//OnTouch
		email_error.setOnTouchListener(new View.OnTouchListener(){
				@Override
				public boolean onTouch(View v, MotionEvent event){
						int ev = event.getAction();
						switch (ev) {
								case MotionEvent.ACTION_DOWN:
								
								 
								
								break;
								case MotionEvent.ACTION_UP:
								
								 
								
								break;
						} return true;
				}
		});
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("email")) {
						email_edittext.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("name")) {
						username_edittext.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("about")) {
						bio_edittext.setText(_childValue.get("about").toString());
					}
					if (_childValue.containsKey("avater")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(profile_image);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					if (_childValue.containsKey("email")) {
						email_edittext.setText(_childValue.get("email").toString());
					}
					if (_childValue.containsKey("name")) {
						username_edittext.setText(_childValue.get("name").toString());
					}
					if (_childValue.containsKey("about")) {
						bio_edittext.setText(_childValue.get("about").toString());
					}
					if (_childValue.containsKey("avater")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("avater").toString())).into(profile_image);
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_upavaver_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				SketchwareUtil.showMessage(getApplicationContext(), String.valueOf((long)(_progressValue)));
			}
		};
		
		_upavaver_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_upavaver_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(profile_image);
				file.edit().remove("picked_path").commit();
				imgpath = _downloadUrl;
				down = _downloadUrl;
				count = 100;
				map = new HashMap<>();
				map.put("avater", _downloadUrl);
				users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
				map.clear();
			}
		};
		
		_upavaver_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_upavaver_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_upavaver_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		imgpath = "";
		down = "";
		fp_avaver = 0;
		count = 0;
		_edittext_logic();
		_ui_setup();
	}
	
	public void _ui_setup() {
		toolbar_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 1);
		username_setted.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 1);
		email_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 0);
		email_edittext.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		email_error.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		username_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 0);
		username_edittext.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		username_error.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		bio_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/medium.ttf"), 0);
		bio_edittext.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		bio_error.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 0);
		at_rate.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/light.ttf"), 1);
		choose_layout.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b, int c, int d) { this.setCornerRadius(a); this.setStroke(b, c); this.setColor(d); return this; } }.getIns((int)360, (int)5, 0xFFFFFFFF, 0xFF1976D2));
		toolbar_title.setTextSize((float)13);
		email_error.setVisibility(View.GONE);
		username_error.setVisibility(View.GONE);
		bio_error.setVisibility(View.GONE);
		_Add("#FFFFFF", choose_image);
		_ripple(back_img);
		_ripple(done_img);
		getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
		getWindow().setStatusBarColor(0xFFFFFFFF);
	}
	
	
	public void _ripple(final View _view) {
		
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
		android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
		int backgroundResource = typedArray.getResourceId(0, 0); _view.setBackgroundResource(backgroundResource);
		_view.setClickable(true);
	}
	
	
	public void _Add(final String _Colour, final ImageView _Imageview) {
		_Imageview.getDrawable().setColorFilter(Color.parseColor(_Colour), PorterDuff.Mode.SRC_IN);
	}
	
	
	public void _edittext_logic() {
		_edittext_on_focus(email_edittext, email_base, email_title, email_error);
		_edittext_on_focus(username_edittext, username_base, username_title, username_error);
		_edittext_on_focus(bio_edittext, bio_base, bio_title, bio_error);
	}
	
	
	public void _edittext_on_focus(final EditText _edittext, final View _base, final TextView _title, final TextView _error) {
		_edittext.setOnFocusChangeListener(new OnFocusChangeListener() { @Override public void onFocusChange(View v, boolean hasFocus) {
				  if (hasFocus) {
					_title.setTextColor(0xFF1976D2);
					_edittext.setTextColor(0xFF212121);
					_TransitionManager(content_wrapper, 200);
					_error.setVisibility(View.GONE);
					final ObjectAnimator backgroundColorAnimator = ObjectAnimator.ofObject(_base,
					                                                                       "backgroundColor",
					                                                                       new ArgbEvaluator(),
					                                                                       0xffBDBDBD,
					                                                                       0xff1976B2);
					backgroundColorAnimator.setDuration(500);
					backgroundColorAnimator.start();
				} 
				 else { 
					_title.setTextColor(0xFFBDBDBD);
					_edittext.setTextColor(0xFF9E9E9E);
					_TransitionManager(content_wrapper, 200);
					_error.setVisibility(View.GONE);
					final ObjectAnimator backgroundColorAnimator = ObjectAnimator.ofObject(_base,
					                                                                       "backgroundColor",
					                                                                       new ArgbEvaluator(),
					                                                                       0xff1976D2,
					                                                                       0xffBDBDBD);
					backgroundColorAnimator.setDuration(500);
					backgroundColorAnimator.start();
				} } });
	}
	
	
	public void _TransitionManager(final View _view, final double _duration) {
		LinearLayout viewgroup =(LinearLayout) _view;
		
		android.transition.AutoTransition autoTransition = new android.transition.AutoTransition(); autoTransition.setDuration((long)_duration); android.transition.TransitionManager.beginDelayedTransition(viewgroup, autoTransition);
	}
	
	
	public void _email_case() {
		_TransitionManager(content_wrapper, 200);
		email_error.setVisibility(View.VISIBLE);
		email_title.setTextColor(0xFFF44336);
		email_edittext.setTextColor(0xFFF44336);
		final ObjectAnimator backgroundColorAnimator = ObjectAnimator.ofObject(email_base,
		                                                                       "backgroundColor",
		                                                                       new ArgbEvaluator(),
		                                                                       0xffEEEEEE,
		                                                                       0xffF44336);
		backgroundColorAnimator.setDuration(500);
		backgroundColorAnimator.start();
	}
	
	
	public void _username_case() {
		_TransitionManager(content_wrapper, 200);
		username_error.setVisibility(View.VISIBLE);
		username_title.setTextColor(0xFFF44336);
		username_edittext.setTextColor(0xFFF44336);
		email_error.setVisibility(View.GONE);
		email_title.setTextColor(0xFFBDBDBD);
		email_base.setBackgroundColor(0xFFBDBDBD);
		final ObjectAnimator backgroundColorAnimator = ObjectAnimator.ofObject(username_base,
		                                                                       "backgroundColor",
		                                                                       new ArgbEvaluator(),
		                                                                       0xffEEEEEE,
		                                                                       0xffF44336);
		backgroundColorAnimator.setDuration(500);
		backgroundColorAnimator.start();
	}
	
	
	public void _bio_case() {
		_TransitionManager(content_wrapper, 200);
		bio_error.setVisibility(View.VISIBLE);
		bio_title.setTextColor(0xFFF44336);
		bio_edittext.setTextColor(0xFFF44336);
		email_error.setVisibility(View.GONE);
		email_title.setTextColor(0xFFBDBDBD);
		email_base.setBackgroundColor(0xFFBDBDBD);
		username_error.setVisibility(View.GONE);
		username_title.setTextColor(0xFFBDBDBD);
		username_base.setBackgroundColor(0xFFBDBDBD);
		final ObjectAnimator backgroundColorAnimator = ObjectAnimator.ofObject(bio_base,
		                                                                       "backgroundColor",
		                                                                       new ArgbEvaluator(),
		                                                                       0xffEEEEEE,
		                                                                       0xffF44336);
		backgroundColorAnimator.setDuration(500);
		backgroundColorAnimator.start();
	}
	
	
	public void _upload_successfully(final String _downloadUrl) {
		if (email_edittext.getText().toString().equals("")) {
			_email_case();
		}
		else {
			if (username_edittext.getText().toString().equals("")) {
				_username_case();
			}
			else {
				if (bio_edittext.getText().toString().equals("")) {
					_bio_case();
				}
				else {
					map = new HashMap<>();
					map.put("name", username_edittext.getText().toString());
					map.put("email", email_edittext.getText().toString());
					map.put("about", bio_edittext.getText().toString());
					users.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
					com.google.android.material.snackbar.Snackbar.make(content_wrapper, "your profile is updated...", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
						@Override
									public void onClick(View _view) {
											 
									}
					}).show();
				}
			}
		}
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}