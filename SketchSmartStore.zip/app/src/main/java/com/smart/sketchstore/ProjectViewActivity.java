package com.smart.sketchstore;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.Activity;
import android.content.*;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.os.Bundle;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.github.angads25.filepicker.*;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.File;
import java.io.InputStream;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;

public class ProjectViewActivity extends AppCompatActivity {
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String PATH_HIDE_SKETCHLIB = "";
	private String PATH_SKETCHLIB = "";
	private String PATH_SKETCHWARE = "";
	private String up_edit = "";
	private String icon_path = "";
	private String up_icon = "";
	private String path = "";
	private String file_size = "";
	private String project_key = "";
	private String new_id = "";
	private double number = 0;
	private boolean liked = false;
	private String like_key = "";
	private String key = "";
	private HashMap<String, Object> map = new HashMap<>();
	private double like_num = 0;
	private HashMap<String, Object> map2 = new HashMap<>();
	private String uid = "";
	private String icon_URL = "";
	private String message = "";
	private String URL = "";
	private String type = "";
	private boolean isVisible = false;
	private double download_num = 0;
	private HashMap<String, Object> map_download2 = new HashMap<>();
	private HashMap<String, Object> decrypt_map = new HashMap<>();
	private String temp_decrypted = "";
	private String SKETCHLIB_PATH = "";
	private String SKETCHLIB_PATH_HIDE = "";
	private String SKETCHWARE_PATH = "";
	private String s1 = "";
	private String s2 = "";
	private String s3 = "";
	private String s4 = "";
	private String s5 = "";
	private String token = "";
	private String serverKey = "";
	private String id = "";
	
	private ArrayList<String> temp = new ArrayList<>();
	private ArrayList<String> copy_list = new ArrayList<>();
	
	private LinearLayout linear2;
	private ScrollView vscroll1;
	private ImageView imageview1;
	private HorizontalScrollView hscroll1;
	private ImageView imageview2;
	private ImageView like_button;
	private LinearLayout linear1;
	private LinearLayout linear3;
	private HorizontalScrollView hscroll3;
	private Button button1;
	private ProgressBar progressbar1;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private HorizontalScrollView hscroll2;
	private LinearLayout linear11;
	private CardView cardview1;
	private LinearLayout linear4;
	private ImageView project_icon;
	private TextView project_title;
	private TextView project_developer;
	private LinearLayout linear13;
	private LinearLayout linear5;
	private LinearLayout linear6;
	private LinearLayout project_verified_layout;
	private LinearLayout editor_choice;
	private LinearLayout linear15;
	private LinearLayout linear14;
	private TextView textview3;
	private TextView like_count;
	private TextView textview5;
	private ImageView imageview5;
	private TextView textview9;
	private ImageView imageview11;
	private TextView category;
	private TextView textview10;
	private TextView textview6;
	private TextView textview7;
	private ImageView imageview6;
	private LinearLayout linear17;
	private ImageView sc1;
	private ImageView sc2;
	private ImageView sc3;
	private ImageView sc4;
	private ImageView sc5;
	private TextView textview8;
	private ImageView imageview10;
	
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private DatabaseReference data1 = _firebase.getReference("data1");
	private ChildEventListener _data1_child_listener;
	private StorageReference project = _firebase_storage.getReference("project");
	private OnCompleteListener<Uri> _project_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _project_download_success_listener;
	private OnSuccessListener _project_delete_success_listener;
	private OnProgressListener _project_upload_progress_listener;
	private OnProgressListener _project_download_progress_listener;
	private OnFailureListener _project_failure_listener;
	
	private TimerTask timer;
	private StorageReference swb_project = _firebase_storage.getReference("swb");
	private OnCompleteListener<Uri> _swb_project_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _swb_project_download_success_listener;
	private OnSuccessListener _swb_project_delete_success_listener;
	private OnProgressListener _swb_project_upload_progress_listener;
	private OnProgressListener _swb_project_download_progress_listener;
	private OnFailureListener _swb_project_failure_listener;
	
	private DatabaseReference like = _firebase.getReference("likes");
	private ChildEventListener _like_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	private DatabaseReference download = _firebase.getReference("download");
	private ChildEventListener _download_child_listener;
	private Intent i = new Intent();
	private SharedPreferences s;
	private AlertDialog dialog;
	private PopupMenu popup;
	private Menu popupmenu;
	private PopupMenu seconduserpoup;
	private Menu seconduserpoupmenu;
	private AlertDialog actiondialog;
	
	private OnCompleteListener notification_onCompleteListener;
	private RequestNetwork requestNetwork;
	private RequestNetwork.RequestListener _requestNetwork_request_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.project_view);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		linear2 = findViewById(R.id.linear2);
		vscroll1 = findViewById(R.id.vscroll1);
		imageview1 = findViewById(R.id.imageview1);
		hscroll1 = findViewById(R.id.hscroll1);
		imageview2 = findViewById(R.id.imageview2);
		like_button = findViewById(R.id.like_button);
		linear1 = findViewById(R.id.linear1);
		linear3 = findViewById(R.id.linear3);
		hscroll3 = findViewById(R.id.hscroll3);
		button1 = findViewById(R.id.button1);
		progressbar1 = findViewById(R.id.progressbar1);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		hscroll2 = findViewById(R.id.hscroll2);
		linear11 = findViewById(R.id.linear11);
		cardview1 = findViewById(R.id.cardview1);
		linear4 = findViewById(R.id.linear4);
		project_icon = findViewById(R.id.project_icon);
		project_title = findViewById(R.id.project_title);
		project_developer = findViewById(R.id.project_developer);
		linear13 = findViewById(R.id.linear13);
		linear5 = findViewById(R.id.linear5);
		linear6 = findViewById(R.id.linear6);
		project_verified_layout = findViewById(R.id.project_verified_layout);
		editor_choice = findViewById(R.id.editor_choice);
		linear15 = findViewById(R.id.linear15);
		linear14 = findViewById(R.id.linear14);
		textview3 = findViewById(R.id.textview3);
		like_count = findViewById(R.id.like_count);
		textview5 = findViewById(R.id.textview5);
		imageview5 = findViewById(R.id.imageview5);
		textview9 = findViewById(R.id.textview9);
		imageview11 = findViewById(R.id.imageview11);
		category = findViewById(R.id.category);
		textview10 = findViewById(R.id.textview10);
		textview6 = findViewById(R.id.textview6);
		textview7 = findViewById(R.id.textview7);
		imageview6 = findViewById(R.id.imageview6);
		linear17 = findViewById(R.id.linear17);
		sc1 = findViewById(R.id.sc1);
		sc2 = findViewById(R.id.sc2);
		sc3 = findViewById(R.id.sc3);
		sc4 = findViewById(R.id.sc4);
		sc5 = findViewById(R.id.sc5);
		textview8 = findViewById(R.id.textview8);
		imageview10 = findViewById(R.id.imageview10);
		auth = FirebaseAuth.getInstance();
		s = getSharedPreferences("s", Activity.MODE_PRIVATE);
		requestNetwork = new RequestNetwork(this);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (uid.equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
					PopupMenu popup = new PopupMenu(ProjectViewActivity.this, imageview2);
					Menu popupmenu = popup.getMenu();
					popupmenu.add("delete project").setIcon(R.drawable.ic_delete_black);
					popupmenu.add("update project").setIcon(R.drawable.ic_edit_black);
					popup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
						public boolean onMenuItemClick(MenuItem popuphi) {
							switch (popuphi.getTitle().toString()) {	
								case "delete project":
								_action_dialog("can you this project has been delete?", "you after delete this project to not recover this project can you delete this project not be recovery this project?", "CANCEL", "DELETE", "USELESS");
								return true;
								case "update project":
								i.setClass(getApplicationContext(), UploadProjectActivity.class);
								i.putExtra("key", key);
								startActivity(i);
								return true;
								default:
								return false;
							}
						}
					});
					try {
						java.lang.reflect.Field[] fields = popup.getClass().getDeclaredFields();
						for (java.lang.reflect.Field field : fields) {
							if ("mPopup".equals(field.getName())) {
								field.setAccessible(true);
								Object menuPopupHelper = field.get(popup); Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
								java.lang.reflect.Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class); setForceIcons.invoke(menuPopupHelper, true);
								break;
							}
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
					popup.show();
				}
				else {
					PopupMenu seconduserpoup = new PopupMenu(ProjectViewActivity.this, imageview2);
					Menu seconduserpoupmenu = seconduserpoup.getMenu();
					seconduserpoupmenu.add("report").setIcon(R.drawable.ic_report_black);
					seconduserpoup.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
						public boolean onMenuItemClick(MenuItem itemmy) {
							switch (itemmy.getTitle().toString()) {	
								case "report":
								 
								return true;
								default:
								return false;
							}
						}
					});
					try {
						java.lang.reflect.Field[] fields = seconduserpoup.getClass().getDeclaredFields();
						for (java.lang.reflect.Field field : fields) {
							if ("mPopup".equals(field.getName())) {
								field.setAccessible(true);
								Object menuPopupHelper = field.get(seconduserpoup); Class<?> classPopupHelper = Class.forName(menuPopupHelper.getClass().getName());
								java.lang.reflect.Method setForceIcons = classPopupHelper.getMethod("setForceShowIcon", boolean.class); setForceIcons.invoke(menuPopupHelper, true);
								break;
							}
						}
					} catch(Exception e) {
						e.printStackTrace();
					}
					seconduserpoup.show();
				}
			}
		});
		
		like_button.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (liked) {
					id = like.push().getKey();
					map = new HashMap<>();
					map.put("value", "false");
					map.put("key", key);
					map.put("like_key", like_key);
					map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					like.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
				}
				else {
					id = like.push().getKey();
					map = new HashMap<>();
					map.put("value", "true");
					map.put("key", key);
					map.put("like_key", like_key);
					map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
					like.child(FirebaseAuth.getInstance().getCurrentUser().getUid()).updateChildren(map);
					map.clear();
				}
			}
		});
		
		button1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (textview10.getText().toString().equals("Sketchware Project")) {
					_firebase_storage.getReferenceFromUrl(URL).getFile(new File(SKETCHLIB_PATH.concat("temp/temp.zip"))).addOnSuccessListener(_project_download_success_listener).addOnFailureListener(_project_failure_listener).addOnProgressListener(_project_download_progress_listener);
				}
				else {
					_firebase_storage.getReferenceFromUrl(URL).getFile(new File(PATH_SKETCHLIB.concat(project_title.getText().toString().concat(".swb")))).addOnSuccessListener(_swb_project_download_success_listener).addOnFailureListener(_swb_project_failure_listener).addOnProgressListener(_swb_project_download_progress_listener);
				}
			}
		});
		
		linear9.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ReadMoreDetailsActivity.class);
				i.putExtra("uid", uid);
				i.putExtra("key", key);
				startActivity(i);
				_TransictionActivity();
			}
		});
		
		linear11.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), CommentsActivity.class);
				i.putExtra("key", key);
				i.putExtra("uid", uid);
				i.putExtra("token", token);
				i.putExtra("name", project_title.getText().toString());
				startActivity(i);
			}
		});
		
		project_developer.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				i.setClass(getApplicationContext(), ProfileActivity.class);
				i.putExtra("uid", uid);
				i.putExtra("mode", "user");
				startActivity(i);
			}
		});
		
		sc1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				s.edit().putString("url", s1).commit();
				startActivity(new Intent(ProjectViewActivity.this, IconViewActivity.class)); Animatoo.animateShrink(ProjectViewActivity.this);
			}
		});
		
		sc2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				s.edit().putString("url", s2).commit();
				startActivity(new Intent(ProjectViewActivity.this, IconViewActivity.class)); Animatoo.animateShrink(ProjectViewActivity.this);
			}
		});
		
		sc3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				s.edit().putString("url", s3).commit();
				startActivity(new Intent(ProjectViewActivity.this, IconViewActivity.class)); Animatoo.animateShrink(ProjectViewActivity.this);
			}
		});
		
		sc4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				s.edit().putString("url", s4).commit();
				startActivity(new Intent(ProjectViewActivity.this, IconViewActivity.class)); Animatoo.animateShrink(ProjectViewActivity.this);
			}
		});
		
		sc5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				s.edit().putString("url", s5).commit();
				startActivity(new Intent(ProjectViewActivity.this, IconViewActivity.class)); Animatoo.animateShrink(ProjectViewActivity.this);
			}
		});
		
		_data1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(key)) {
					if (_childValue.containsKey("icon")) {
						Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("icon").toString())).into(project_icon);
						icon_URL = _childValue.get("icon").toString();
					}
					else {
						project_icon.setImageResource(R.drawable.android_icon);
					}
					if (_childValue.containsKey("title")) {
						project_title.setText(_childValue.get("title").toString());
					}
					if (_childValue.containsKey("likes")) {
						like_count.setText(_childValue.get("likes").toString());
					}
					if (_childValue.containsKey("project")) {
						URL = _childValue.get("project").toString();
					}
					if (_childValue.containsKey("type")) {
						textview10.setText(_childValue.get("type").toString());
					}
					else {
						textview10.setText("Sketchware Project");
					}
					if (_childValue.containsKey("editor")) {
						if (_childValue.containsValue("true")) {
							editor_choice.setVisibility(View.VISIBLE);
						}
						else {
							editor_choice.setVisibility(View.GONE);
						}
					}
					if (_childValue.containsKey("catagory")) {
						category.setText(_childValue.get("catagory").toString());
					}
					else {
						category.setText("UI & UX");
					}
					if (_childValue.containsKey("size")) {
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										button1.setText("Download project".concat("(".concat(_childValue.get("size").toString()).concat(")")));
									}
								});
							}
						};
						_timer.schedule(timer, (int)(700));
					}
					else {
						timer = new TimerTask() {
							@Override
							public void run() {
								runOnUiThread(new Runnable() {
									@Override
									public void run() {
										button1.setText("Download project");
									}
								});
							}
						};
						_timer.schedule(timer, (int)(700));
					}
					if (_childValue.containsKey("dec")) {
						
					}
					if (_childValue.containsKey("new")) {
						if (_childValue.get("new").toString().equals("")) {
							textview6.setText("not available");
						}
						else {
							//Do not remove
							/*
MADE BY PETER ESSYEN
Give me credit if you decide to use, share this codes or project
*/
							message = _childValue.get("new").toString();
							Pattern p = Pattern.compile("(\\*\\*)(.*?)(\\*\\*)");
							    Matcher matcher = p.matcher(message);
							
							    SpannableStringBuilder spannable = new SpannableStringBuilder(message);
							    List<StyleSpan> spans = new ArrayList<>();
							    //for making text bold
							    while (matcher.find()) {
								        StyleSpan span = new StyleSpan(Typeface.BOLD);
								        spannable.setSpan(span, matcher.start(), matcher.end(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
								        spans.add(span);
								    }
							    //for removing ** text
							    for (StyleSpan span : spans) {
								        spannable.replace(spannable.getSpanStart(span), spannable.getSpanStart(span) + 2, "");
								        spannable.replace(spannable.getSpanEnd(span) - 2, spannable.getSpanEnd(span), "");
								    }
								
							textview6.setText(spannable);
						}
					}
					if (_childValue.containsKey("sc1")) {
						if (_childValue.get("sc1").toString().equals("")) {
							sc1.setVisibility(View.GONE);
						}
						else {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc1").toString())).into(sc1);
							s1 = _childValue.get("sc1").toString();
							sc1.setVisibility(View.VISIBLE);
						}
					}
					else {
						Glide.with(getApplicationContext()).load(Uri.parse("file:///android_asset/your.gif")).into(sc1);
					}
					if (_childValue.containsKey("sc2")) {
						if (_childValue.get("sc2").toString().equals("")) {
							sc2.setVisibility(View.GONE);
						}
						else {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc2").toString())).into(sc2);
							sc2.setVisibility(View.VISIBLE);
							s2 = _childValue.get("sc2").toString();
						}
					}
					else {
						Glide.with(getApplicationContext()).load(Uri.parse("file:///android_asset/your.gif")).into(sc2);
					}
					if (_childValue.containsKey("sc3")) {
						if (_childValue.get("sc3").toString().equals("")) {
							sc3.setVisibility(View.GONE);
						}
						else {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc3").toString())).into(sc3);
							sc3.setVisibility(View.VISIBLE);
							s3 = _childValue.get("sc3").toString();
						}
					}
					else {
						Glide.with(getApplicationContext()).load(Uri.parse("file:///android_asset/your.gif")).into(sc3);
					}
					if (_childValue.containsKey("sc4")) {
						if (_childValue.get("sc4").toString().equals("")) {
							sc4.setVisibility(View.GONE);
						}
						else {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc4").toString())).into(sc4);
							sc4.setVisibility(View.VISIBLE);
							s4 = _childValue.get("sc4").toString();
						}
					}
					else {
						Glide.with(getApplicationContext()).load(Uri.parse("file:///android_asset/your.gif")).into(sc4);
					}
					if (_childValue.containsKey("sc5")) {
						if (_childValue.get("sc5").toString().equals("")) {
							sc5.setVisibility(View.GONE);
						}
						else {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc5").toString())).into(sc5);
							sc5.setVisibility(View.VISIBLE);
							s5 = _childValue.get("sc5").toString();
						}
					}
					else {
						Glide.with(getApplicationContext()).load(Uri.parse("file:///android_asset/your.gif")).into(sc5);
					}
					if (_childValue.containsKey("verified")) {
						if (_childValue.get("verified").toString().equals("true")) {
							project_verified_layout.setVisibility(View.VISIBLE);
						}
						else {
							project_verified_layout.setVisibility(View.GONE);
						}
					}
					else {
						project_verified_layout.setVisibility(View.GONE);
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				SketchwareUtil.showMessage(getApplicationContext(), "data changed..");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				finish();
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data1.addChildEventListener(_data1_child_listener);
		
		_project_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_project_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				progressbar1.setVisibility(View.VISIBLE);
				_setProgressbarColor(progressbar1, "#4CAF50");
			}
		};
		
		_project_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_project_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				progressbar1.setVisibility(View.GONE);
				button1.setText("Downloading...");
				_UnZip(SKETCHLIB_PATH.concat("temp/temp.zip"), SKETCHLIB_PATH_HIDE);
				_New_ID_Generation();
				FileUtil.makeDir(SKETCHWARE_PATH.concat("data/".concat(new_id)));
				FileUtil.makeDir(SKETCHWARE_PATH.concat("mysc/list/".concat(new_id)));
				FileUtil.makeDir(SKETCHWARE_PATH.concat("resources/fonts/".concat(new_id)));
				FileUtil.makeDir(SKETCHWARE_PATH.concat("resources/icons/".concat(new_id)));
				FileUtil.makeDir(SKETCHWARE_PATH.concat("resources/images/".concat(new_id)));
				FileUtil.makeDir(SKETCHWARE_PATH.concat("resources/sounds/".concat(new_id)));
				_Decrypt(SKETCHLIB_PATH_HIDE.concat("temp/list/project"));
				decrypt_map = new HashMap<>();
				decrypt_map = new Gson().fromJson(temp_decrypted, new TypeToken<HashMap<String, Object>>(){}.getType());
				decrypt_map.put("sc_id", new_id);
				temp_decrypted = new Gson().toJson(decrypt_map);
				_Encrypt(SKETCHLIB_PATH_HIDE.concat("temp/list/project"));
				_Copy(SKETCHLIB_PATH_HIDE.concat("temp/data"), SKETCHWARE_PATH.concat("data/".concat(new_id)));
				_Copy(SKETCHLIB_PATH_HIDE.concat("temp/list/"), SKETCHWARE_PATH.concat("mysc/list/".concat(new_id)));
				_Copy(SKETCHLIB_PATH_HIDE.concat("temp/fonts/"), SKETCHWARE_PATH.concat("resources/fonts/".concat(new_id)));
				_Copy(SKETCHLIB_PATH_HIDE.concat("temp/icons/"), SKETCHWARE_PATH.concat("resources/icons/".concat(new_id)));
				_Copy(SKETCHLIB_PATH_HIDE.concat("temp/images/"), SKETCHWARE_PATH.concat("resources/images/".concat(new_id)));
				_Copy(SKETCHLIB_PATH_HIDE.concat("temp/sounds/"), SKETCHWARE_PATH.concat("resources/sounds/".concat(new_id)));
				timer = new TimerTask() {
					@Override
					public void run() {
						runOnUiThread(new Runnable() {
							@Override
							public void run() {
								button1.setText("");
								button1.setText("Download complete.");
								button1.setEnabled(false);
								FileUtil.deleteFile(SKETCHLIB_PATH_HIDE.concat("temp"));
								download_num++;
								map_download2 = new HashMap<>();
								map_download2.put("download", String.valueOf((long)(download_num)));
								download.child(key).updateChildren(map_download2);
								users.child(uid).updateChildren(map_download2);
								map_download2.clear();
							}
						});
					}
				};
				_timer.schedule(timer, (int)(2500));
			}
		};
		
		_project_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_project_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_swb_project_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_swb_project_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				progressbar1.setVisibility(View.VISIBLE);
			}
		};
		
		_swb_project_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				
			}
		};
		
		_swb_project_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				progressbar1.setVisibility(View.GONE);
				download_num++;
				map_download2 = new HashMap<>();
				map_download2.put("download", String.valueOf((long)(download_num)));
				download.child(key).updateChildren(map_download2);
				users.child(uid).updateChildren(map_download2);
				map_download2.clear();
				_CustomDialog("your project has been download sucess.", "download success to : ".concat(PATH_SKETCHLIB.concat("/".concat(project_title.getText().toString().concat(".swb")))), "", "OK");
			}
		};
		
		_swb_project_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_swb_project_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_like_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((_childValue.containsKey("key") && _childValue.containsKey("value")) && _childValue.containsKey("uid")) {
					if (key.equals(_childValue.get("key").toString()) && _childValue.get("value").toString().equals("true")) {
						like_num++;
						id = like.push().getKey();
						map2 = new HashMap<>();
						map2.put("likes", String.valueOf((long)(like_num)));
						data1.child(key.concat(FirebaseAuth.getInstance().getCurrentUser().getUid())).updateChildren(map2);
						map2.clear();
					}
					if (key.equals(_childValue.get("key").toString()) && _childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.get("value").toString().equals("true")) {
							like_button.setImageResource(R.drawable.heart_rad);
							liked = true;
						}
						else {
							like_button.setImageResource(R.drawable.ic_favorite_outline_grey);
							liked = false;
						}
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if ((_childValue.containsKey("key") && _childValue.containsKey("value")) && _childValue.containsKey("uid")) {
					if (key.equals(_childValue.get("key").toString()) && _childValue.get("value").toString().equals("true")) {
						like_num++;
						map2 = new HashMap<>();
						map2.put("likes", String.valueOf((long)(like_num)));
						data1.child(key.concat(FirebaseAuth.getInstance().getCurrentUser().getUid())).updateChildren(map2);
						map2.clear();
					}
					if (key.equals(_childValue.get("key").toString()) && _childValue.get("uid").toString().equals(FirebaseAuth.getInstance().getCurrentUser().getUid())) {
						if (_childValue.get("value").toString().equals("true")) {
							like_button.setImageResource(R.drawable.heart_rad);
							liked = true;
						}
						else {
							like_button.setImageResource(R.drawable.ic_favorite_outline_grey);
							liked = false;
						}
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		like.addChildEventListener(_like_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(uid)) {
					if (_childValue.containsKey("name")) {
						project_developer.setText(_childValue.get("name").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(uid)) {
					if (_childValue.containsKey("name")) {
						project_developer.setText(_childValue.get("name").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
		
		_download_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(key)) {
					if (_childValue.containsKey("download")) {
						download_num = Double.parseDouble(_childValue.get("download").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(key)) {
					if (_childValue.containsKey("download")) {
						download_num = Double.parseDouble(_childValue.get("download").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		download.addChildEventListener(_download_child_listener);
		
		notification_onCompleteListener = new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(Task<InstanceIdResult> task) {
				final boolean _success = task.isSuccessful();
				final String _token = task.getResult().getToken();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_requestNetwork_request_listener = new RequestNetwork.RequestListener() {
			@Override
			public void onResponse(String _param1, String _param2, HashMap<String, Object> _param3) {
				final String _tag = _param1;
				final String _response = _param2;
				final HashMap<String, Object> _responseHeaders = _param3;
				
			}
			
			@Override
			public void onErrorResponse(String _param1, String _param2) {
				final String _tag = _param1;
				final String _message = _param2;
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		key = getIntent().getStringExtra("key");
		uid = getIntent().getStringExtra("uid");
		like.removeEventListener(_like_child_listener);
		like_key = key.concat(FirebaseAuth.getInstance().getCurrentUser().getUid().concat(getIntent().getStringExtra("uid")));
		like =
		_firebase.getReference(like_key);
		like.addChildEventListener(_like_child_listener);
		like_num = 0;
		download_num = 0;
		PATH_SKETCHWARE = FileUtil.getExternalStorageDir().concat("/.sketchware/");
		PATH_HIDE_SKETCHLIB = FileUtil.getExternalStorageDir().concat("/.SKETCH SMART STORE/");
		PATH_SKETCHLIB = FileUtil.getExternalStorageDir().concat("/download/Sketch Smart Store/Sketchware Pro/");
		if (!FileUtil.isExistFile(PATH_SKETCHWARE)) {
			FileUtil.makeDir(PATH_SKETCHWARE);
		}
		if (!FileUtil.isExistFile(PATH_HIDE_SKETCHLIB)) {
			FileUtil.makeDir(PATH_HIDE_SKETCHLIB);
		}
		if (!FileUtil.isExistFile(PATH_SKETCHLIB)) {
			FileUtil.makeDir(PATH_SKETCHLIB);
		}
		SKETCHLIB_PATH = FileUtil.getExternalStorageDir().concat("/download/Sketch Smart Store/");
		SKETCHLIB_PATH_HIDE = FileUtil.getExternalStorageDir().concat("/.Sketch Smart Store LIB/");
		SKETCHWARE_PATH = FileUtil.getExternalStorageDir().concat("/.sketchware/");
		if (!FileUtil.isExistFile(SKETCHLIB_PATH)) {
			FileUtil.makeDir(SKETCHLIB_PATH);
		}
		if (!FileUtil.isExistFile(SKETCHLIB_PATH_HIDE)) {
			FileUtil.makeDir(SKETCHLIB_PATH_HIDE);
		}
		if (!FileUtil.isExistFile(SKETCHWARE_PATH)) {
			FileUtil.makeDir(SKETCHWARE_PATH);
		}
		button1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		project_title.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		project_developer.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		like_count.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		category.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/mostafa.ttf"), 0);
		progressbar1.setVisibility(View.GONE);
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			_subscribeFCMTopic("all");
			serverKey = "AAAAQMZlKP8:APA91bH0JgFNGHaZyrivaYwcwPrf9xw5buKcDBu3MdJcgHJrEDp7OwBXudrU4a3NMRBwOMkdAXZqPMxAHg91IDH5Myvk9bnZjNudSryvlYCA42hOAlZvAFo3rnVxDxi43I7mx5YU4Rt0";
			_getDeviceFCMToken();
		}
		else {
			
		}
		_ripple(imageview1);
		_ripple(imageview2);
		_ripple(like_button);
		_ripple(sc1);
		_ripple(sc2);
		_ripple(sc3);
		_ripple(sc4);
		_ripple(sc5);
	}
	
	public void _New_ID_Generation() {
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list"), temp);
		Collections.sort(temp, String.CASE_INSENSITIVE_ORDER);
		if (temp.size() == 0) {
			new_id = "601";
		}
		else {
			try {
				new_id = String.valueOf((long)(Double.parseDouble(Uri.parse(temp.get((int)(temp.size() - 1))).getLastPathSegment()) + 1));
			} catch(Exception e) {
			}
		}
	}
	
	
	public void _UnZip(final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _Decrypt(final String _path) {
		try {
			javax.crypto.Cipher instance = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] bytes = "sketchwaresecure".getBytes();
			instance.init(2, new javax.crypto.spec.SecretKeySpec(bytes, "AES"), new javax.crypto.spec.IvParameterSpec(bytes));
			java.io.RandomAccessFile randomAccessFile = new java.io.RandomAccessFile(_path, "r");
			byte[] bArr = new byte[((int) randomAccessFile.length())];
			randomAccessFile.readFully(bArr);
			temp_decrypted = new String(instance.doFinal(bArr));
		} catch(Exception e) {
			showMessage(e.toString());
		}
	}
	
	
	public void _zip(final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks.\nModified By: Rohit Verma", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	public void _Encrypt(final String _path) {
		try {
			javax.crypto.Cipher instance = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] bytes = "sketchwaresecure".getBytes();
			instance.init(1, new javax.crypto.spec.SecretKeySpec(bytes, "AES"), new javax.crypto.spec.IvParameterSpec(bytes));
			new java.io.RandomAccessFile(_path, "rw").write(instance.doFinal(temp_decrypted.getBytes()));
		} catch(Exception e) {
			showMessage(e.toString());
		}
	}
	
	
	public void _Copy(final String _F, final String _T) {
		FileUtil.makeDir(_T.concat("/"));
		copy_list.clear();
		FileUtil.listDir(_F.concat("/"), copy_list);
		number = 0;
		for(int _repeat11 = 0; _repeat11 < (int)(copy_list.size()); _repeat11++) {
			if (FileUtil.isFile(copy_list.get((int)(number)))) {
				FileUtil.copyFile(copy_list.get((int)(number)), _T.concat("/".concat(Uri.parse(copy_list.get((int)(number))).getLastPathSegment())));
			}
			number++;
		}
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			isVisible = true;
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout background = (LinearLayout)coreprog.findViewById(R.id.background);
			
			LinearLayout layout_progress = (LinearLayout)coreprog.findViewById(R.id.layout_progress);
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#EEEEEE")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
			RadialProgressView progress = new RadialProgressView(this);
			layout_progress.addView(progress);
		}
		else {
			isVisible = false;
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _setProgressbarColor(final ProgressBar _prog, final String _color) {
		if (android.os.Build.VERSION.SDK_INT >= 21) {
			_prog.getIndeterminateDrawable().setColorFilter(Color.parseColor(_color), PorterDuff.Mode.SRC_IN);
			//KerDev
		}
	}
	
	
	public void _CustomDialog(final String _mesg, final String _title, final String _canceltext, final String _done) {
		final AlertDialog dialog = new AlertDialog.Builder(ProjectViewActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.dialog,null); dialog.setView(inflate);
		LinearLayout l1 = (LinearLayout)inflate.findViewById(R.id.l1);
		LinearLayout l3 = (LinearLayout)inflate.findViewById(R.id.l3);
		LinearLayout l4 = (LinearLayout)inflate.findViewById(R.id.l4);
		ScrollView hs = (ScrollView)inflate.findViewById(R.id.hs);
		TextView t1 = (TextView)inflate.findViewById(R.id.t1);
		TextView m1 = (TextView)inflate.findViewById(R.id.m1);
		TextView t3 = (TextView)inflate.findViewById(R.id.t3);
		TextView t4 = (TextView)inflate.findViewById(R.id.t4);
		l1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFFFFF));
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		m1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		t3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		t4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		t3.setTextColor(0xFFF44336);
		t4.setTextColor(0xFF2962FF);
		t1.setText(_title);
		m1.setText(_mesg);
		t3.setText(_canceltext);
		t4.setText(_done);
		t4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						finish();
				}
		});
		dialog.setCancelable(true);
		dialog.show();
	}
	
	
	public void _TransictionActivity() {
		overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
	}
	
	
	public void _action_dialog(final String _titl, final String _desc, final String _button1, final String _button2, final String _mesg) {
		// mesg is waste
		final AlertDialog actiondialog = new AlertDialog.Builder(ProjectViewActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.action_dialog,null); actiondialog.setView(inflate);
		LinearLayout lin = (LinearLayout)inflate.findViewById(R.id.linear1);
		pl.droidsonroids.gif.GifImageView lin2 = (pl.droidsonroids.gif.GifImageView)inflate.findViewById(R.id.linear2);
		LinearLayout lin3 = (LinearLayout)inflate.findViewById(R.id.linear3);
		LinearLayout lin4 = (LinearLayout)inflate.findViewById(R.id.linear4);
		LinearLayout lin5 = (LinearLayout)inflate.findViewById(R.id.linear5);
		TextView txt1 = (TextView)inflate.findViewById(R.id.textview);
		TextView txt2 = (TextView)inflate.findViewById(R.id.textview_message);
		TextView but1 = (TextView)inflate.findViewById(R.id.but1);
		TextView but2 = (TextView)inflate.findViewById(R.id.but2);
		lin.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFFFFF));
		lin.setBackgroundColor(0xFFFFFFFF);
		lin3.setBackgroundColor(0xFFFFFFFF);
		lin4.setBackgroundColor(0xFFFFFFFF);
		lin5.setBackgroundColor(0xFFFFFFFF);
		txt1.setTextColor(0xFFF66555);
		txt1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		txt2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		but1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		but2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		txt2.setTextColor(0xFF3F51B6);
		but1.setTextColor(0xFF2196F3);
		but2.setTextColor(0xFFF44336);
		txt1.setText(_titl);
		txt2.setText(_desc);
		but1.setText(_button1);
		but2.setText(_button2);
		but1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						actiondialog.dismiss();
				}
		});
		but2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						data1.child(key).removeValue();
				}
		});
		actiondialog.setCancelable(true);
		actiondialog.show();
	}
	
	
	public void _subscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().subscribeToTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
					} else {
					}}});
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _unsubscribeFCMTopic(final String _name) {
		if (_name.matches("[a-zA-Z0-9-_.~%]{1,900}")) {
			String topicName = java.text.Normalizer.normalize(_name, java.text.Normalizer.Form.NFD);
			topicName = topicName.replaceAll("[\\p{InCombiningDiacriticalMarks}]", "");
			FirebaseMessaging.getInstance().unsubscribeFromTopic(topicName).addOnCompleteListener(new OnCompleteListener<Void>() {
				@Override
				public void onComplete(@NonNull Task<Void> task) {
					if (task.isSuccessful()) {
						SketchwareUtil.showMessage(getApplicationContext(), "Unsubscribed Successfully");
					} else {
						SketchwareUtil.showMessage(getApplicationContext(), "Couldn't Unsubscribe");
					}}});
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Badly Formated Topic");
		}
	}
	
	
	public void _getDeviceFCMToken() {
		FirebaseInstanceId.getInstance().getInstanceId().addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
			@Override
			public void onComplete(@NonNull Task<InstanceIdResult> task) {
				if (task.isSuccessful()) {
					token = task.getResult().getToken();
					
					
					
					
					// here my_token is textview
					
					
					
				} else {
					
					
					
				}}});
	}
	
	
	public void _sendFCMNotification(final String _key, final String _title, final String _content, final String _imageUrl, final String _topic, final String _token) {
		if (SketchwareUtil.isConnected(getApplicationContext())) {
			HashMap<String, Object> requestHeader = new HashMap<>();
			
			HashMap<String, Object> notificationBody = new HashMap<>();
			
			HashMap<String, Object> requestBody = new HashMap<>();
			requestHeader = new HashMap<>();
			requestHeader.put("Authorization", "key=".concat(_key));
			requestHeader.put("Content-Type", "application/json");
			
			notificationBody = new HashMap<>();
			notificationBody.put("title", _title);
			notificationBody.put("body", _content);
			notificationBody.put("image", _imageUrl);
			
			requestBody = new HashMap<>();
			if (!_topic.equals("null")) {
				requestBody.put("to", "/topics/".concat(_topic));
			} else {
				requestBody.put("to", _token);
			}
			requestBody.put("notification", notificationBody);
			requestNetwork.setHeaders(requestHeader);
			requestNetwork.setParams(requestBody, RequestNetworkController.REQUEST_BODY);
			requestNetwork.startRequestNetwork(RequestNetworkController.POST, "https://fcm.googleapis.com/fcm/send", "", _requestNetwork_request_listener);
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "No Internet Connection");
		}
	}
	
	
	public void _ripple(final View _view) {
		
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
		android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
		int backgroundResource = typedArray.getResourceId(0, 0); _view.setBackgroundResource(backgroundResource);
		_view.setClickable(true);
	}
	
	
	public void _SuccessDialog(final String _titl, final String _desc, final String _button1, final String _button2, final String _mesg) {
		// mesg is waste
		final AlertDialog actiondialog = new AlertDialog.Builder(ProjectViewActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.action_dialog,null); actiondialog.setView(inflate);
		LinearLayout lin = (LinearLayout)inflate.findViewById(R.id.linear1);
		pl.droidsonroids.gif.GifImageView lin2 = (pl.droidsonroids.gif.GifImageView)inflate.findViewById(R.id.linear2);
		LinearLayout lin3 = (LinearLayout)inflate.findViewById(R.id.linear3);
		LinearLayout lin4 = (LinearLayout)inflate.findViewById(R.id.linear4);
		LinearLayout lin5 = (LinearLayout)inflate.findViewById(R.id.linear5);
		TextView txt1 = (TextView)inflate.findViewById(R.id.textview);
		TextView txt2 = (TextView)inflate.findViewById(R.id.textview_message);
		TextView but1 = (TextView)inflate.findViewById(R.id.but1);
		TextView but2 = (TextView)inflate.findViewById(R.id.but2);
		lin.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)40, 0xFFFFFFFF));
		lin.setBackgroundColor(0xFFFFFFFF);
		lin3.setBackgroundColor(0xFFFFFFFF);
		lin4.setBackgroundColor(0xFFFFFFFF);
		lin5.setBackgroundColor(0xFFFFFFFF);
		txt1.setTextColor(0xFFF66555);
		txt1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		txt2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		but1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		but2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		txt2.setTextColor(0xFF3F51B6);
		but1.setTextColor(0xFF2196F3);
		but2.setTextColor(0xFFF44336);
		txt1.setText(_titl);
		txt2.setText(_desc);
		but1.setText(_button1);
		but2.setText(_button2);
		but1.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						 
				}
		});
		but2.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						actiondialog.dismiss();
				}
		});
		actiondialog.setCancelable(true);
		actiondialog.show();
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}