package com.smart.sketchstore;

import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.github.angads25.filepicker.*;
import com.google.firebase.FirebaseApp;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;

public class ReadMoreDetailsActivity extends AppCompatActivity {
	
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	
	private HashMap<String, Object> map = new HashMap<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear2;
	private LinearLayout linear7;
	private LinearLayout linear8;
	private LinearLayout linear9;
	private LinearLayout linear44;
	private LinearLayout linear32;
	private LinearLayout linear45;
	private LinearLayout linear17;
	private LinearLayout linear33;
	private LinearLayout linear46;
	private LinearLayout linear49;
	private LinearLayout linear52;
	private LinearLayout linear55;
	private ImageView imageview1;
	private LinearLayout linear5;
	private TextView title;
	private TextView textview3;
	private TextView whats_new;
	private TextView whatsnew_text;
	private TextView about;
	private TextView about_text;
	private TextView textview14;
	private TextView textview31;
	private LinearLayout linear34;
	private LinearLayout linear40;
	private TextView down_count;
	private TextView textview37;
	private LinearLayout linear47;
	private LinearLayout linear48;
	private TextView update_date;
	private TextView textview39;
	private LinearLayout linear50;
	private LinearLayout linear51;
	private TextView name;
	private TextView textview41;
	private LinearLayout linear53;
	private LinearLayout linear54;
	private TextView upload_date;
	private TextView textview42;
	private LinearLayout linear56;
	private LinearLayout linear57;
	private TextView category;
	
	private DatabaseReference data1 = _firebase.getReference("data1");
	private ChildEventListener _data1_child_listener;
	private DatabaseReference download = _firebase.getReference("download");
	private ChildEventListener _download_child_listener;
	private DatabaseReference users = _firebase.getReference("users");
	private ChildEventListener _users_child_listener;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.read_more_details);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		initializeLogic();
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear2 = findViewById(R.id.linear2);
		linear7 = findViewById(R.id.linear7);
		linear8 = findViewById(R.id.linear8);
		linear9 = findViewById(R.id.linear9);
		linear44 = findViewById(R.id.linear44);
		linear32 = findViewById(R.id.linear32);
		linear45 = findViewById(R.id.linear45);
		linear17 = findViewById(R.id.linear17);
		linear33 = findViewById(R.id.linear33);
		linear46 = findViewById(R.id.linear46);
		linear49 = findViewById(R.id.linear49);
		linear52 = findViewById(R.id.linear52);
		linear55 = findViewById(R.id.linear55);
		imageview1 = findViewById(R.id.imageview1);
		linear5 = findViewById(R.id.linear5);
		title = findViewById(R.id.title);
		textview3 = findViewById(R.id.textview3);
		whats_new = findViewById(R.id.whats_new);
		whatsnew_text = findViewById(R.id.whatsnew_text);
		about = findViewById(R.id.about);
		about_text = findViewById(R.id.about_text);
		textview14 = findViewById(R.id.textview14);
		textview31 = findViewById(R.id.textview31);
		linear34 = findViewById(R.id.linear34);
		linear40 = findViewById(R.id.linear40);
		down_count = findViewById(R.id.down_count);
		textview37 = findViewById(R.id.textview37);
		linear47 = findViewById(R.id.linear47);
		linear48 = findViewById(R.id.linear48);
		update_date = findViewById(R.id.update_date);
		textview39 = findViewById(R.id.textview39);
		linear50 = findViewById(R.id.linear50);
		linear51 = findViewById(R.id.linear51);
		name = findViewById(R.id.name);
		textview41 = findViewById(R.id.textview41);
		linear53 = findViewById(R.id.linear53);
		linear54 = findViewById(R.id.linear54);
		upload_date = findViewById(R.id.upload_date);
		textview42 = findViewById(R.id.textview42);
		linear56 = findViewById(R.id.linear56);
		linear57 = findViewById(R.id.linear57);
		category = findViewById(R.id.category);
		
		_data1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("key"))) {
					if (_childValue.containsKey("title")) {
						title.setText(_childValue.get("title").toString());
					}
					if (_childValue.containsKey("dec")) {
						about_text.setText(_childValue.get("dec").toString());
					}
					if (_childValue.containsKey("new")) {
						whatsnew_text.setText(_childValue.get("new").toString());
					}
					if (_childValue.containsKey("update date")) {
						update_date.setText(_childValue.get("update date").toString());
					}
					if (_childValue.containsKey("time")) {
						upload_date.setText(_childValue.get("time").toString());
					}
					if (_childValue.containsKey("catagory")) {
						category.setText(_childValue.get("catagory").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("key"))) {
					if (_childValue.containsKey("title")) {
						title.setText(_childValue.get("title").toString());
					}
					if (_childValue.containsKey("dec")) {
						about_text.setText(_childValue.get("dec").toString());
					}
					if (_childValue.containsKey("new")) {
						whatsnew_text.setText(_childValue.get("new").toString());
					}
					if (_childValue.containsKey("update date")) {
						update_date.setText(_childValue.get("update date").toString());
					}
					if (_childValue.containsKey("time")) {
						upload_date.setText(_childValue.get("time").toString());
					}
					if (_childValue.containsKey("catagory")) {
						category.setText(_childValue.get("catagory").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data1.addChildEventListener(_data1_child_listener);
		
		_download_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("key"))) {
					if (_childValue.containsKey("download")) {
						down_count.setText(_childValue.get("download").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("key"))) {
					if (_childValue.containsKey("download")) {
						down_count.setText(_childValue.get("download").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		download.addChildEventListener(_download_child_listener);
		
		_users_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					if (_childValue.containsKey("name")) {
						name.setText(_childValue.get("name").toString());
					}
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (_childKey.equals(getIntent().getStringExtra("uid"))) {
					if (_childValue.containsKey("name")) {
						name.setText(_childValue.get("name").toString());
					}
				}
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		users.addChildEventListener(_users_child_listener);
	}
	
	private void initializeLogic() {
		_ripple(imageview1);
	}
	
	public void _ripple(final View _view) {
		
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
		android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
		int backgroundResource = typedArray.getResourceId(0, 0); _view.setBackgroundResource(backgroundResource);
		_view.setClickable(true);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}