package com.smart.sketchstore;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.ArrayAdapter;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.github.angads25.filepicker.*;
import com.github.angads25.filepicker.controller.DialogSelectionListener ;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.text.*;
import java.util.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;
import android.transition.*;
import javax.crypto.Cipher;
import javax.crypto.spec.*;
import com.google.android.material.textfield.TextInputLayout;
import java.io.File;
import java.io.RandomAccessFile;
import com.github.angads25.filepicker.controller.DialogSelectionListener ;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;

public class SketchwareManagerActivity extends AppCompatActivity {
	
	private FloatingActionButton _fab;
	private HashMap<String, Object> a = new HashMap<>();
	private HashMap<String, Object> b = new HashMap<>();
	private HashMap<String, Object> project_info_map = new HashMap<>();
	private String S_Projects = "";
	private String data = "";
	private String mysc = "";
	private String list = "";
	private String icons = "";
	private String comment = "";
	private String fonts = "";
	private String images = "";
	private String sounds = "";
	private HashMap<String, Object> myprojects_map = new HashMap<>();
	private double myprojects_number = 0;
	private String buildGradle = "";
	private String name = "";
	private String id = "";
	private String sat = "";
	private HashMap<String, Object> hm = new HashMap<>();
	private String file_info = "";
	private String newId = "";
	private String newID = "";
	private double nums = 0;
	private String path = "";
	private String swb_ = "";
	private String swb_file = "";
	private String file_size = "";
	private double second_number = 0;
	private double first_number = 0;
	
	private ArrayList<String> myprojects_string = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> myprojects_list = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> projects_list = new ArrayList<>();
	
	private LinearLayout linear2;
	private LinearLayout linear3;
	private ImageView imageview1;
	private TextView textview1;
	private ListView listview1;
	
	private FilePickerDialog fpd;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.sketchware_manager);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		_fab = findViewById(R.id._fab);
		
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		imageview1 = findViewById(R.id.imageview1);
		textview1 = findViewById(R.id.textview1);
		listview1 = findViewById(R.id.listview1);
		
		linear2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				DialogProperties fpdp = new DialogProperties();
				fpdp.selection_mode = DialogConfigs.MULTI_MODE;
				fpdp.selection_type = DialogConfigs.FILE_SELECT;
				fpdp.root = new java.io.File(FileUtil.getExternalStorageDir());
				fpdp.error_dir = new java.io.File(FileUtil.getExternalStorageDir());
				fpdp.offset = new java.io.File(FileUtil.getExternalStorageDir());
				fpdp.extensions = new String[] {".swb"};
				fpd = new FilePickerDialog(SketchwareManagerActivity.this,fpdp);
				fpd.setTitle("pick a restore file (.swb) file");
				fpd.setPositiveBtnName("restore");
				fpd.setNegativeBtnName("cancel");
				fpd.setDialogSelectionListener(new DialogSelectionListener() {
					@Override public void onSelectedFilePaths(String[] files) {
						path = Arrays.asList(files).get((int) 0).toString();
						if(path.contains(".swb")){
								if (FileUtil.isFile(path)) {
											S4U.selecteSWB(path, getApplicationContext());
										
										//REMOVE TEMPORARY FILE BECAUSE NOT MARGE TWO PROJECT FILES
											while(S4U._is_finish()) {
												 FileUtil.deleteFile(FileUtil.getPackageDataDir(getApplicationContext()).concat("/swb_restore/"));
														break;
											}
								}
								else {
											
								SketchwareUtil.showMessage(getApplicationContext(), "INVALID SWB PATH");
								  }
						} 
						else {
							SketchwareUtil.showMessage(getApplicationContext(), "THIS FILE IS NOT SWB");
						}
					} 
				});
				fpd.show();
			}
		});
		
		_fab.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				final AlertDialog create = new AlertDialog.Builder(SketchwareManagerActivity.this).create();
				final View _inflate = getLayoutInflater().inflate(R.layout.project_info_dialog, null);
				create.setView(_inflate);
				final EditText edittext1 = _inflate.findViewById(R.id.edittext1);
				final EditText package_name = _inflate.findViewById(R.id.package_name);
				final EditText project_name = _inflate.findViewById(R.id.project_name);
				final EditText version_code = _inflate.findViewById(R.id.version_code);
				final EditText version_name = _inflate.findViewById(R.id.version_name);
				final TextInputLayout pid = _inflate.findViewById(R.id.textinputlayout6);
				final ImageView img = _inflate.findViewById(R.id.circleimageview1);
				final TextView cancel_button = _inflate.findViewById(R.id.cancel_button);
				final TextView create_button = _inflate.findViewById(R.id.save_button);
				final LinearLayout advanced_settings = _inflate.findViewById(R.id.advanced_settings);
				final LinearLayout advanced_settings_field = _inflate.findViewById(R.id.advanced_settings_field);
				pid.setVisibility(View.GONE);
				create_button.setText("CREATE");
				project_name.setText("NewProject");
				package_name.setText("com.smart.sketchstore");
				version_name.setText("0.1");
				version_code.setText("1");
				create_button.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
								try {
										if (!((edittext1.getText().toString().trim().equals("") || project_name.getText().toString().trim().equals("")) || (package_name.getText().toString().trim().equals("") || (version_name.getText().toString().trim().equals("") || version_code.getText().toString().trim().equals(""))))) {
												String newID = "";
												if (projects_list.size() > 0) {
														if (_isNumber(projects_list.get((int)0).get("sc_id").toString())) {
																newID = String.valueOf((long)(Double.parseDouble(projects_list.get((int)0).get("sc_id").toString()) + 1));
														}
														else {
																for(int _repeat53 = 0; _repeat53 < (int)(projects_list.size()); _repeat53++) {
																		if (_isNumber(projects_list.get((int)_repeat53).get("sc_id").toString())) {
																				newID = String.valueOf((long)(Double.parseDouble(projects_list.get((int)_repeat53).get("sc_id").toString()) + 1));
																				break;
																		}
																}
														}
												}
												else {
														newID = "1";
												}
												FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(newID.concat("/project"))), "");
												FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(newID.concat("/view"))), "");
												FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(newID.concat("/logic"))), "");
												FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(newID.concat("/file"))), "");
												FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(newID.concat("/resource"))), "");
												FileUtil.writeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/data/".concat(newID.concat("/library"))), "");
												HashMap<String, Object> hm = new HashMap<String, Object>();
												hm.put("custom_icon", false);
												hm.put("sc_id", newID);
												hm.put("sc_ver_code", version_code.getText().toString().trim());
												hm.put("sc_ver_name", version_name.getText().toString().trim());
												hm.put("my_app_name", edittext1.getText().toString().trim());
												hm.put("my_ws_name", project_name.getText().toString().trim());
												hm.put("my_sc_pkg_name", package_name.getText().toString().trim());
												hm.put("my_sc_reg_dt", new SimpleDateFormat("yyyyMMddHHmmss").format(new Date(System.currentTimeMillis())));
												hm.put("color_accent", 0xFF008DCD);
												hm.put("color_primary", 0xFF2196F3);
												hm.put("color_primary_dark", 0xFF1976D2);
												hm.put("color_control_normal", 0xFFE1F5FE);
												hm.put("color_control_highlight", 0xFFB3E5FC);
												hm.put("sketchware_ver", 150);
												file_info = new Gson().toJson(hm);
												_storeUnencryptedSketchwareProjectFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(newID.concat("/project"))));
												create.dismiss();
												_refreshProjectsList(projects_list);
												((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
										}
								} catch (Exception s){
										new AlertDialog.Builder(SketchwareManagerActivity.this).setMessage(android.util.Log.getStackTraceString(s)).create().show();
								}
						}
				});
				cancel_button.setOnClickListener(new View.OnClickListener() {
						@Override
						public void onClick(View _view) {
								create.dismiss();
						}
				});
				
				create.show();
			}
		});
	}
	
	private void initializeLogic() {
		_project_list();
	}
	
	public void _sortFileList(final ArrayList<HashMap<String, Object>> _listMap) {
		if (!(_listMap.isEmpty() || _listMap == null)) {
			Collections.sort(_listMap, new Comparator<HashMap<String, Object>>(){
				public int compare(HashMap<String, Object> a, HashMap<String, Object> b){
					final boolean is_numberA = _isNumber(a.get("sc_id").toString());
					final boolean is_numberB = _isNumber(b.get("sc_id").toString());
					if (is_numberA && is_numberB) {
						final Long first_number = Long.valueOf(a.get("sc_id").toString());
						final Long second_number = Long.valueOf(b.get("sc_id").toString());
						return (second_number.compareTo(first_number));
					}
					else {
						return (a.get("sc_id").toString().toLowerCase().compareTo(b.get("sc_id").toString().toLowerCase()));
					}
				}});
		}
	}
	
	
	public void _refreshProjectsList(final ArrayList<HashMap<String, Object>> _listMap) {
		if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list"))) {
			if (projects_list.size() > 0) {
				projects_list.clear();
			}
			File[] items = new File(Environment.getExternalStorageDirectory().toString().concat("/.sketchware/mysc/list")).listFiles();
			for (File item : items){
				if (FileUtil.isExistFile(item.getPath().concat("/project"))) {
					project_info_map = new HashMap<>();
					project_info_map = new Gson().fromJson(_decryptSketchwareProjectFiles(item.getPath().concat("/project")), new TypeToken<HashMap<String, Object>>(){}.getType());
					project_info_map.put("folder_id", item.getName());
					_listMap.add(project_info_map);
				}
			}
			_sortFileList(projects_list);
		}
		else {
			SketchwareUtil.showMessage(getApplicationContext(), "Did you even use Sketchware, m8?");
		}
	}
	
	
	public void _storeUnencryptedSketchwareProjectFile(final String _path) {
		try{
			Cipher instance = Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] pwd = "sketchwaresecure".getBytes();
			instance.init(1, new SecretKeySpec(pwd, "AES"), new IvParameterSpec(pwd));
			new RandomAccessFile(_path, "rw").write(instance.doFinal(file_info.getBytes()));
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), "0x01: ".concat(e.toString()));
		}
	}
	
	
	public boolean _isNumber(final String _string) {
		try{
			final int nums = Integer.parseInt(_string);
			return (true);
		}catch(Exception e){
			return (false);
		}
	}
	
	
	public String _decryptSketchwareProjectFiles(final String _path) {
		try{
			Cipher instance = Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] password = "sketchwaresecure".getBytes();
			instance.init(2, new SecretKeySpec(password, "AES"), new IvParameterSpec(password));
			RandomAccessFile file = new RandomAccessFile(_path, "r");
			byte[] size = new byte[(int)file.length()];
			file.readFully(size);
			final String output = new String(instance.doFinal(size));
			return (output);
		}catch(Exception e){
			SketchwareUtil.showMessage(getApplicationContext(), e.toString());
			return ("");
		}
	}
	
	
	public void _project_list() {
		S_Projects = FileUtil.getExternalStorageDir().concat("/SW Backup/");
		data = FileUtil.getExternalStorageDir().concat("/.sketchware/data/");
		mysc = FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/");
		list = FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/");
		icons = FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/");
		comment = FileUtil.getExternalStorageDir().concat("/.sketchware/resources/comment/");
		fonts = FileUtil.getExternalStorageDir().concat("/.sketchware/resources/fonts/");
		images = FileUtil.getExternalStorageDir().concat("/.sketchware/resources/images/");
		sounds = FileUtil.getExternalStorageDir().concat("/.sketchware/resources/sounds/");
		projects_list.clear();
		myprojects_string.clear();
		myprojects_map.clear();
		FileUtil.listDir(list, myprojects_string);
		Collections.sort(myprojects_string, String.CASE_INSENSITIVE_ORDER);
		myprojects_number = 0;
		for(int _repeat45 = 0; _repeat45 < (int)(myprojects_string.size()); _repeat45++) {
			myprojects_map = new HashMap<>();
			myprojects_map.put("icon", icons.concat(Uri.parse(myprojects_string.get((int)(myprojects_number))).getLastPathSegment()).concat("/icon.png"));
			myprojects_map.put("number", Uri.parse(myprojects_string.get((int)(myprojects_number))).getLastPathSegment());
			if (FileUtil.readFile(mysc.concat(Uri.parse(myprojects_string.get((int)(myprojects_number))).getLastPathSegment().concat("/app/build.gradle"))).equals("")) {
				myprojects_map.put("package", "No package");
			}
			else {
				buildGradle = FileUtil.readFile(mysc.concat(Uri.parse(myprojects_string.get((int)(myprojects_number))).getLastPathSegment().concat("/app/build.gradle")));
				name = buildGradle.substring((int)(buildGradle.indexOf("applicationId")), (int)(buildGradle.indexOf("minSdkVersion")));
				name = name.replace("applicationId \"", "");
				name = name.replace("\"", "");
				myprojects_map.put("package", name.trim());
			}
			id = Uri.parse(myprojects_string.get((int)(myprojects_number))).getLastPathSegment();
			sat = "";
			try { java.io.File folder = new java.io.File(Environment.getExternalStorageDirectory(), ".sketchware/mysc/" + id + "/bin");
				java.io.File[] listOfFiles = folder.listFiles();
				
				for(int b = 0; b < listOfFiles.length; b++) {
					    if (listOfFiles[b].getName().endsWith(".apk.res")) {
						        sat = listOfFiles[b].getName();
						sat = sat.substring((int)(0), (int)(sat.indexOf(".apk.res")));
						break;
						    }
				} } catch(Exception e) {}
			if (sat.equals("")) {
				myprojects_map.put("title", "[UNKNOWN]");
			}
			else {
				myprojects_map.put("title", sat.trim().replace("_", " "));
			}
			projects_list.add(myprojects_map);
			myprojects_number++;
		}
		listview1.setAdapter(new Listview1Adapter(projects_list));
		Collections.reverse(SketchwareManagerActivity.this.myprojects_list);
		((BaseAdapter)listview1.getAdapter()).notifyDataSetChanged();
	}
	
	public class Listview1Adapter extends BaseAdapter {
		
		ArrayList<HashMap<String, Object>> _data;
		
		public Listview1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		
		@Override
		public int getCount() {
			return _data.size();
		}
		
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		
		@Override
		public View getView(final int _position, View _v, ViewGroup _container) {
			LayoutInflater _inflater = getLayoutInflater();
			View _view = _v;
			if (_view == null) {
				_view = _inflater.inflate(R.layout.cus, null);
			}
			
			final LinearLayout back = _view.findViewById(R.id.back);
			final LinearLayout click = _view.findViewById(R.id.click);
			final ImageView icon = _view.findViewById(R.id.icon);
			final LinearLayout linear3 = _view.findViewById(R.id.linear3);
			final TextView textview1 = _view.findViewById(R.id.textview1);
			final TextView title = _view.findViewById(R.id.title);
			final TextView pack = _view.findViewById(R.id.pack);
			
			if (_data.get((int)_position).containsKey("icon")) {
				if (FileUtil.readFile(_data.get((int)_position).get("icon").toString()).length() > 0) {
					icon.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(_data.get((int)_position).get("icon").toString(), 1024, 1024));
				}
				else {
					icon.setImageResource(R.drawable.android_icon);
				}
			}
			else {
				icon.setImageResource(R.drawable.android_icon);
			}
			if (_data.get((int)_position).containsKey("title")) {
				title.setText(_data.get((int)_position).get("title").toString());
			}
			if (_data.get((int)_position).containsKey("package")) {
				pack.setText(_data.get((int)_position).get("package").toString());
			}
			if (_data.get((int)_position).containsKey("number")) {
				textview1.setText(_data.get((int)_position).get("number").toString());
			}
			
			return _view;
		}
	}
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}