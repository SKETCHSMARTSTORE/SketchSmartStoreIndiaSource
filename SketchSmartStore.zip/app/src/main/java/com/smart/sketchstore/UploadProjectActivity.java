package com.smart.sketchstore;

import android.Manifest;
import android.animation.*;
import android.app.*;
import android.app.AlertDialog;
import android.content.*;
import android.content.ClipData;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.*;
import android.graphics.*;
import android.graphics.Typeface;
import android.graphics.drawable.*;
import android.media.*;
import android.net.*;
import android.net.Uri;
import android.os.*;
import android.text.*;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.style.*;
import android.util.*;
import android.view.*;
import android.view.View;
import android.view.View.*;
import android.view.animation.*;
import android.webkit.*;
import android.widget.*;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import com.blogspot.atifsoftwares.animatoolib.*;
import com.bumptech.glide.Glide;
import com.github.angads25.filepicker.*;
import com.github.angads25.filepicker.controller.DialogSelectionListener ;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;
import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.FirebaseApp;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.GenericTypeIndicator;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FileDownloadTask;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.OnProgressListener;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.mao.*;
import com.mursaat.extendedtextview.*;
import com.shobhitpuri.custombuttons.*;
import io.github.rosemoe.sora.*;
import io.github.rosemoe.sora.langs.base.*;
import io.github.rosemoe.sora.langs.css3.*;
import io.github.rosemoe.sora.langs.html.*;
import io.github.rosemoe.sora.langs.java.*;
import io.github.rosemoe.sora.langs.python.*;
import io.github.rosemoe.sora.langs.textmate.*;
import io.github.rosemoe.sora.langs.universal.*;
import java.io.*;
import java.io.File;
import java.text.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.*;
import org.json.*;
import pl.droidsonroids.gif.*;
import s4u.restore.swb.*;
import uk.co.senab.photoview.*;
import com.github.angads25.filepicker.controller.DialogSelectionListener ;
import com.github.angads25.filepicker.model.DialogConfigs;
import com.github.angads25.filepicker.model.DialogProperties;
import com.github.angads25.filepicker.view.FilePickerDialog;

public class UploadProjectActivity extends AppCompatActivity {
	
	public final int REQ_CD_P_ICON = 101;
	public final int REQ_CD_SC1 = 102;
	public final int REQ_CD_SC2 = 103;
	public final int REQ_CD_SC3 = 104;
	public final int REQ_CD_SC4 = 105;
	public final int REQ_CD_SC5 = 106;
	public final int REQ_CD_SWB = 107;
	
	private Timer _timer = new Timer();
	private FirebaseDatabase _firebase = FirebaseDatabase.getInstance();
	private FirebaseStorage _firebase_storage = FirebaseStorage.getInstance();
	
	private String s1path = "";
	private String s1name = "";
	private String s2path = "";
	private String s2name = "";
	private String s3path = "";
	private String s3name = "";
	private String s4path = "";
	private String s4name = "";
	private String s5path = "";
	private String s5name = "";
	private String iconpath = "";
	private String iconname = "";
	private String swb_ = "";
	private String swb_file = "";
	private String path = "";
	private String file_size = "";
	private String ProjectType = "";
	private double typeID = 0;
	private String projectpath = "";
	private String projectname = "";
	private HashMap<String, Object> temp_map1 = new HashMap<>();
	private double number = 0;
	private String temp_decrypted = "";
	private String new_id = "";
	private String PATH_HIDE_SKETCHLIB = "";
	private String PATH_SKETCHLIB = "";
	private String PATH_SKETCHWARE = "";
	private String up_edit = "";
	private String icon_path = "";
	private String up_icon = "";
	private String project_key = "";
	private boolean isVisible = false;
	private double files_count = 0;
	private String project_url = "";
	private String upload1 = "";
	private String upload2 = "";
	private String upload3 = "";
	private String upload4 = "";
	private String upload5 = "";
	private String uploadicon = "";
	private HashMap<String, Object> data_map = new HashMap<>();
	private double B = 0;
	private double KB = 0;
	private double MB = 0;
	private double GB = 0;
	private double TB = 0;
	private double PB = 0;
	private String returnedSize = "";
	private String update_key = "";
	private String uid = "";
	private String lieks = "";
	private String comments = "";
	private String size = "";
	private String editor = "";
	private String time = "";
	private String verified = "";
	private HashMap<String, Object> update_map = new HashMap<>();
	
	private ArrayList<String> temp_str1 = new ArrayList<>();
	private ArrayList<HashMap<String, Object>> temp_listmap1 = new ArrayList<>();
	private ArrayList<String> temp = new ArrayList<>();
	private ArrayList<String> copy_list = new ArrayList<>();
	private ArrayList<String> files = new ArrayList<>();
	
	private ScrollView vscroll1;
	private LinearLayout linear1;
	private LinearLayout linear26;
	private LinearLayout linear2;
	private LinearLayout linear3;
	private LinearLayout linear7;
	private LinearLayout linear11;
	private LinearLayout linear18;
	private LinearLayout linear20;
	private LinearLayout linear22;
	private ImageView imageview6;
	private TextView textview13;
	private ImageView imageview7;
	private LinearLayout linear12;
	private TextView textview8;
	private ImageView icon;
	private EditText tit;
	private LinearLayout linear4;
	private TextView textview3;
	private HorizontalScrollView hscroll3;
	private TextView textview1;
	private TextView textview2;
	private LinearLayout linear14;
	private LinearLayout linear5;
	private ImageView s1;
	private ImageView s2;
	private ImageView s3;
	private ImageView s4;
	private ImageView s5;
	private LinearLayout linear8;
	private EditText des;
	private TextView textview9;
	private TextView textview5;
	private TextView textview6;
	private TextView textview7;
	private EditText whatne;
	private TextView textview10;
	private LinearLayout linear19;
	private TextView textview_category;
	private ImageView imageview3;
	private LinearLayout linear21;
	private TextView textview11;
	private ImageView imageview4;
	private LinearLayout linear23;
	private TextView textview12;
	private ImageView imageview5;
	
	private Intent p_icon = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent sc1 = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent sc2 = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent sc3 = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent sc4 = new Intent(Intent.ACTION_GET_CONTENT);
	private Intent sc5 = new Intent(Intent.ACTION_GET_CONTENT);
	private StorageReference up1 = _firebase_storage.getReference("up1");
	private OnCompleteListener<Uri> _up1_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _up1_download_success_listener;
	private OnSuccessListener _up1_delete_success_listener;
	private OnProgressListener _up1_upload_progress_listener;
	private OnProgressListener _up1_download_progress_listener;
	private OnFailureListener _up1_failure_listener;
	
	private StorageReference iconup = _firebase_storage.getReference("iconup");
	private OnCompleteListener<Uri> _iconup_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _iconup_download_success_listener;
	private OnSuccessListener _iconup_delete_success_listener;
	private OnProgressListener _iconup_upload_progress_listener;
	private OnProgressListener _iconup_download_progress_listener;
	private OnFailureListener _iconup_failure_listener;
	
	private StorageReference up2 = _firebase_storage.getReference("up");
	private OnCompleteListener<Uri> _up2_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _up2_download_success_listener;
	private OnSuccessListener _up2_delete_success_listener;
	private OnProgressListener _up2_upload_progress_listener;
	private OnProgressListener _up2_download_progress_listener;
	private OnFailureListener _up2_failure_listener;
	
	private StorageReference up3 = _firebase_storage.getReference("up3");
	private OnCompleteListener<Uri> _up3_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _up3_download_success_listener;
	private OnSuccessListener _up3_delete_success_listener;
	private OnProgressListener _up3_upload_progress_listener;
	private OnProgressListener _up3_download_progress_listener;
	private OnFailureListener _up3_failure_listener;
	
	private StorageReference up4 = _firebase_storage.getReference("up");
	private OnCompleteListener<Uri> _up4_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _up4_download_success_listener;
	private OnSuccessListener _up4_delete_success_listener;
	private OnProgressListener _up4_upload_progress_listener;
	private OnProgressListener _up4_download_progress_listener;
	private OnFailureListener _up4_failure_listener;
	
	private StorageReference up5 = _firebase_storage.getReference("up5");
	private OnCompleteListener<Uri> _up5_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _up5_download_success_listener;
	private OnSuccessListener _up5_delete_success_listener;
	private OnProgressListener _up5_upload_progress_listener;
	private OnProgressListener _up5_download_progress_listener;
	private OnFailureListener _up5_failure_listener;
	
	private AlertDialog.Builder dialog;
	private StorageReference project = _firebase_storage.getReference("project");
	private OnCompleteListener<Uri> _project_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _project_download_success_listener;
	private OnSuccessListener _project_delete_success_listener;
	private OnProgressListener _project_upload_progress_listener;
	private OnProgressListener _project_download_progress_listener;
	private OnFailureListener _project_failure_listener;
	
	private TimerTask timer;
	private DatabaseReference data1 = _firebase.getReference("data1");
	private ChildEventListener _data1_child_listener;
	private Calendar calendar = Calendar.getInstance();
	private FirebaseAuth auth;
	private OnCompleteListener<AuthResult> _auth_create_user_listener;
	private OnCompleteListener<AuthResult> _auth_sign_in_listener;
	private OnCompleteListener<Void> _auth_reset_password_listener;
	private OnCompleteListener<Void> auth_updateEmailListener;
	private OnCompleteListener<Void> auth_updatePasswordListener;
	private OnCompleteListener<Void> auth_emailVerificationSentListener;
	private OnCompleteListener<Void> auth_deleteUserListener;
	private OnCompleteListener<Void> auth_updateProfileListener;
	private OnCompleteListener<AuthResult> auth_phoneAuthListener;
	private OnCompleteListener<AuthResult> auth_googleSignInListener;
	
	private StorageReference swb_uploads = _firebase_storage.getReference("swb");
	private OnCompleteListener<Uri> _swb_uploads_upload_success_listener;
	private OnSuccessListener<FileDownloadTask.TaskSnapshot> _swb_uploads_download_success_listener;
	private OnSuccessListener _swb_uploads_delete_success_listener;
	private OnProgressListener _swb_uploads_upload_progress_listener;
	private OnProgressListener _swb_uploads_download_progress_listener;
	private OnFailureListener _swb_uploads_failure_listener;
	
	private FilePickerDialog fp;
	private Intent swb = new Intent(Intent.ACTION_GET_CONTENT);
	private AlertDialog UploadSuccessDialog;
	
	@Override
	protected void onCreate(Bundle _savedInstanceState) {
		super.onCreate(_savedInstanceState);
		setContentView(R.layout.upload_project);
		initialize(_savedInstanceState);
		FirebaseApp.initializeApp(this);
		
		if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED
		|| ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_DENIED) {
			ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE, Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1000);
		} else {
			initializeLogic();
		}
	}
	
	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		if (requestCode == 1000) {
			initializeLogic();
		}
	}
	
	private void initialize(Bundle _savedInstanceState) {
		vscroll1 = findViewById(R.id.vscroll1);
		linear1 = findViewById(R.id.linear1);
		linear26 = findViewById(R.id.linear26);
		linear2 = findViewById(R.id.linear2);
		linear3 = findViewById(R.id.linear3);
		linear7 = findViewById(R.id.linear7);
		linear11 = findViewById(R.id.linear11);
		linear18 = findViewById(R.id.linear18);
		linear20 = findViewById(R.id.linear20);
		linear22 = findViewById(R.id.linear22);
		imageview6 = findViewById(R.id.imageview6);
		textview13 = findViewById(R.id.textview13);
		imageview7 = findViewById(R.id.imageview7);
		linear12 = findViewById(R.id.linear12);
		textview8 = findViewById(R.id.textview8);
		icon = findViewById(R.id.icon);
		tit = findViewById(R.id.tit);
		linear4 = findViewById(R.id.linear4);
		textview3 = findViewById(R.id.textview3);
		hscroll3 = findViewById(R.id.hscroll3);
		textview1 = findViewById(R.id.textview1);
		textview2 = findViewById(R.id.textview2);
		linear14 = findViewById(R.id.linear14);
		linear5 = findViewById(R.id.linear5);
		s1 = findViewById(R.id.s1);
		s2 = findViewById(R.id.s2);
		s3 = findViewById(R.id.s3);
		s4 = findViewById(R.id.s4);
		s5 = findViewById(R.id.s5);
		linear8 = findViewById(R.id.linear8);
		des = findViewById(R.id.des);
		textview9 = findViewById(R.id.textview9);
		textview5 = findViewById(R.id.textview5);
		textview6 = findViewById(R.id.textview6);
		textview7 = findViewById(R.id.textview7);
		whatne = findViewById(R.id.whatne);
		textview10 = findViewById(R.id.textview10);
		linear19 = findViewById(R.id.linear19);
		textview_category = findViewById(R.id.textview_category);
		imageview3 = findViewById(R.id.imageview3);
		linear21 = findViewById(R.id.linear21);
		textview11 = findViewById(R.id.textview11);
		imageview4 = findViewById(R.id.imageview4);
		linear23 = findViewById(R.id.linear23);
		textview12 = findViewById(R.id.textview12);
		imageview5 = findViewById(R.id.imageview5);
		p_icon.setType("image/*");
		p_icon.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		sc1.setType("image/*");
		sc1.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		sc2.setType("image/*");
		sc2.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		sc3.setType("image/*");
		sc3.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		sc4.setType("image/*");
		sc4.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		sc5.setType("image/*");
		sc5.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		dialog = new AlertDialog.Builder(this);
		auth = FirebaseAuth.getInstance();
		swb.setType("*/*");
		swb.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
		
		linear26.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				
			}
		});
		
		linear18.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_oops();
			}
		});
		
		linear20.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				_ProjectTypeDialog();
			}
		});
		
		linear22.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (ProjectType.equals("SK")) {
					_Load_Projects();
					_Show_Projects_Dialog();
				}
				else {
					if (ProjectType.equals("SW")) {
						startActivityForResult(swb, REQ_CD_SWB);
					}
					else {
						_Load_Projects();
						_Show_Projects_Dialog();
					}
				}
			}
		});
		
		imageview6.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				finish();
			}
		});
		
		imageview7.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				if (uploadicon.equals("")) {
					com.google.android.material.snackbar.Snackbar.make(vscroll1, "please upload icon", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
						@Override
									public void onClick(View _view) {
											 
									}
					}).show();
				}
				else {
					if (upload1.equals("")) {
						com.google.android.material.snackbar.Snackbar.make(vscroll1, "please upload screenshot1", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
							@Override
										public void onClick(View _view) {
												 
										}
						}).show();
					}
					else {
						if (upload2.equals("")) {
							com.google.android.material.snackbar.Snackbar.make(vscroll1, "please upload screenshot2", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
								@Override
											public void onClick(View _view) {
													 
											}
							}).show();
						}
						else {
							if (tit.getText().toString().equals("")) {
								com.google.android.material.snackbar.Snackbar.make(vscroll1, "please add title", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
									@Override
												public void onClick(View _view) {
														 
												}
								}).show();
							}
							else {
								if (des.getText().toString().equals("")) {
									com.google.android.material.snackbar.Snackbar.make(vscroll1, "please fill description", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
										@Override
													public void onClick(View _view) {
															 
													}
									}).show();
								}
								else {
									if (whatne.getText().toString().equals("")) {
										com.google.android.material.snackbar.Snackbar.make(vscroll1, "please fill name what's new", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
											@Override
														public void onClick(View _view) {
																 
														}
										}).show();
									}
									else {
										if (project_url.equals("")) {
											com.google.android.material.snackbar.Snackbar.make(vscroll1, "please upload project to continue", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
												@Override
															public void onClick(View _view) {
																	 
															}
											}).show();
										}
										else {
											if (textview_category.getText().toString().equals("select category")) {
												com.google.android.material.snackbar.Snackbar.make(vscroll1, "please category select", com.google.android.material.snackbar.Snackbar.LENGTH_SHORT).setAction("ok", new View.OnClickListener(){
													@Override
																public void onClick(View _view) {
																		 
																}
												}).show();
											}
											else {
												imageview7.setEnabled(false);
												_telegramLoaderDialog(true);
												//activity has key do not delete to not work update feature...
												if (getIntent().hasExtra("key")) {
													update_map = new HashMap<>();
													if (!uploadicon.equals("")) {
														update_map.put("icon", uploadicon);
													}
													update_map.put("title", tit.getText().toString());
													update_map.put("dec", des.getText().toString());
													update_map.put("new", whatne.getText().toString());
													update_map.put("catagory", textview_category.getText().toString());
													update_map.put("type", textview11.getText().toString());
													update_map.put("sc1", upload1);
													update_map.put("sc2", upload2);
													update_map.put("sc3", upload3);
													update_map.put("sc4", upload4);
													update_map.put("sc5", upload5);
													update_map.put("project", project_url);
													update_map.put("uid", uid);
													update_map.put("key", update_key);
													update_map.put("likes", lieks);
													update_map.put("comments", comments);
													if (size.equals("")) {
														update_map.put("size", returnedSize);
													}
													else {
														update_map.put("size", size);
													}
													update_map.put("editor", editor);
													update_map.put("time", time);
													update_map.put("verified", verified);
													update_map.put("project updated", "true");
													update_map.put("update date", new SimpleDateFormat("dd/MM/yyyy - hh:mm a").format(calendar.getTime()));
													data1.child(update_key).updateChildren(update_map);
													update_map.clear();
													timer = new TimerTask() {
														@Override
														public void run() {
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	_telegramLoaderDialog(false);
																	_CustomDialog("your project has been updated...", "update success!", "", "Exit");
																}
															});
														}
													};
													_timer.schedule(timer, (int)(5000));
												}
												else {
													project_key = data1.push().getKey();
													data_map = new HashMap<>();
													if (!uploadicon.equals("")) {
														data_map.put("icon", uploadicon);
													}
													data_map.put("title", tit.getText().toString());
													data_map.put("dec", des.getText().toString());
													data_map.put("new", whatne.getText().toString());
													data_map.put("catagory", textview_category.getText().toString());
													data_map.put("type", textview11.getText().toString());
													data_map.put("sc1", upload1);
													data_map.put("sc2", upload2);
													data_map.put("sc3", upload3);
													data_map.put("sc4", upload4);
													data_map.put("sc5", upload5);
													data_map.put("download", "0");
													data_map.put("project", project_url);
													data_map.put("uid", FirebaseAuth.getInstance().getCurrentUser().getUid());
													data_map.put("key", project_key);
													data_map.put("likes", "0");
													data_map.put("comments", "0");
													data_map.put("size", returnedSize);
													data_map.put("editor", "false");
													data_map.put("time", new SimpleDateFormat("dd/MM/yyyy - hh:mm a").format(calendar.getTime()));
													data_map.put("verified", "false");
													data_map.put("project updated", "false");
													data_map.put("update date", new SimpleDateFormat("dd/MM/yyyy - hh:mm a").format(calendar.getTime()));
													data1.child(project_key).updateChildren(data_map);
													data_map.clear();
													timer = new TimerTask() {
														@Override
														public void run() {
															runOnUiThread(new Runnable() {
																@Override
																public void run() {
																	_telegramLoaderDialog(false);
																	_CustomDialog("your project has been uploaded...", "upload success!", "", "Exit");
																}
															});
														}
													};
													_timer.schedule(timer, (int)(5000));
												}
											}
										}
									}
								}
							}
						}
					}
				}
			}
		});
		
		icon.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(p_icon, REQ_CD_P_ICON);
			}
		});
		
		tit.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				textview8.setText(String.valueOf((long)(_charSeq.length())).concat("/50"));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		s1.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(sc1, REQ_CD_SC1);
			}
		});
		
		s2.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(sc2, REQ_CD_SC2);
			}
		});
		
		s3.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(sc3, REQ_CD_SC3);
			}
		});
		
		s4.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(sc4, REQ_CD_SC4);
			}
		});
		
		s5.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View _view) {
				startActivityForResult(sc5, REQ_CD_SC5);
			}
		});
		
		des.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				textview9.setText(String.valueOf((long)(_charSeq.length())).concat("/2000"));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		whatne.addTextChangedListener(new TextWatcher() {
			@Override
			public void onTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				final String _charSeq = _param1.toString();
				textview10.setText(String.valueOf((long)(_charSeq.length())).concat("/255"));
			}
			
			@Override
			public void beforeTextChanged(CharSequence _param1, int _param2, int _param3, int _param4) {
				
			}
			
			@Override
			public void afterTextChanged(Editable _param1) {
				
			}
		});
		
		_up1_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up1_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up1_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				upload1 = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(s1);
				_telegramLoaderDialog(false);
			}
		};
		
		_up1_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_up1_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_up1_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_iconup_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_iconup_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_iconup_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				uploadicon = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(icon);
				_telegramLoaderDialog(false);
			}
		};
		
		_iconup_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_iconup_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_iconup_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_up2_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up2_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up2_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				upload2 = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(s2);
				_telegramLoaderDialog(false);
			}
		};
		
		_up2_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_up2_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_up2_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_up3_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up3_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up3_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				upload3 = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(s3);
				_telegramLoaderDialog(false);
			}
		};
		
		_up3_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_up3_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_up3_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_up4_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up4_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up4_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				upload4 = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(s4);
				_telegramLoaderDialog(false);
			}
		};
		
		_up4_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_up4_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_up4_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_up5_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up5_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_up5_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				upload5 = _downloadUrl;
				Glide.with(getApplicationContext()).load(Uri.parse(_downloadUrl)).into(s5);
				_telegramLoaderDialog(false);
			}
		};
		
		_up5_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_up5_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_up5_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_project_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_project_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_project_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				project_url = _downloadUrl;
				_telegramLoaderDialog(false);
				if (!up_icon.equals("")) {
					iconup.child(up_edit.concat(project_key.concat(".png"))).putFile(Uri.fromFile(new File(up_icon))).addOnFailureListener(_iconup_failure_listener).addOnProgressListener(_iconup_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return iconup.child(up_edit.concat(project_key.concat(".png"))).getDownloadUrl();
						}}).addOnCompleteListener(_iconup_upload_success_listener);
					_telegramLoaderDialog(true);
				}
			}
		};
		
		_project_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_project_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_project_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		_data1_child_listener = new ChildEventListener() {
			@Override
			public void onChildAdded(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				if (getIntent().hasExtra("key")) {
					if (_childKey.equals(getIntent().getStringExtra("key"))) {
						if (_childValue.containsKey("key")) {
							update_key = getIntent().getStringExtra("key");
						}
						else {
							
						}
						if (_childValue.containsKey("icon")) {
							Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("icon").toString())).into(icon);
							uploadicon = _childValue.get("icon").toString();
						}
						else {
							icon.setImageResource(R.drawable.android_icon);
							uploadicon = "";
						}
						if (_childValue.containsKey("title")) {
							tit.setText(_childValue.get("title").toString());
						}
						if (_childValue.containsKey("type")) {
							textview11.setText(_childValue.get("type").toString());
						}
						else {
							textview11.setText("Sketchware Project");
						}
						if (_childValue.containsKey("catagory")) {
							textview_category.setText(_childValue.get("catagory").toString());
						}
						else {
							textview_category.setText("Select Category");
						}
						if (_childValue.containsKey("dec")) {
							des.setText(_childValue.get("dec").toString());
						}
						if (_childValue.containsKey("new")) {
							if (_childValue.get("new").toString().equals("")) {
								
							}
							else {
								whatne.setText(_childValue.get("new").toString());
							}
						}
						if (_childValue.containsKey("sc1")) {
							if (_childValue.get("sc1").toString().equals("")) {
								upload1 = "";
							}
							else {
								Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc1").toString())).into(s1);
								upload1 = _childValue.get("sc1").toString();
							}
						}
						else {
							
						}
						if (_childValue.containsKey("sc2")) {
							if (_childValue.get("sc2").toString().equals("")) {
								upload2 = "";
							}
							else {
								Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc2").toString())).into(s2);
								upload2 = _childValue.get("sc2").toString();
							}
						}
						else {
							
						}
						if (_childValue.containsKey("sc3")) {
							if (_childValue.get("sc3").toString().equals("")) {
								upload3 = "";
							}
							else {
								Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc3").toString())).into(s3);
								upload3 = _childValue.get("sc3").toString();
							}
						}
						else {
							
						}
						if (_childValue.containsKey("sc4")) {
							if (_childValue.get("sc4").toString().equals("")) {
								upload4 = "";
							}
							else {
								Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc4").toString())).into(s4);
								upload4 = _childValue.get("sc4").toString();
							}
						}
						else {
							
						}
						if (_childValue.containsKey("sc5")) {
							if (_childValue.get("sc5").toString().equals("")) {
								upload5 = "";
							}
							else {
								Glide.with(getApplicationContext()).load(Uri.parse(_childValue.get("sc5").toString())).into(s5);
								upload5 = _childValue.get("sc4").toString();
							}
						}
						else {
							
						}
						if (_childValue.containsKey("project")) {
							if (_childValue.get("project").toString().equals("")) {
								project_url = "";
							}
							else {
								project_url = _childValue.get("project").toString();
							}
						}
						else {
							project_url = "";
						}
						if (_childValue.containsKey("uid")) {
							uid = _childValue.get("uid").toString();
						}
						if (_childValue.containsKey("likes")) {
							lieks = _childValue.get("likes").toString();
						}
						if (_childValue.containsKey("comments")) {
							comments = _childValue.get("comments").toString();
						}
						if (_childValue.containsKey("size")) {
							size = _childValue.get("size").toString();
						}
						if (_childValue.containsKey("editor")) {
							if (_childValue.get("editor").toString().equals("true")) {
								editor = _childValue.get("editor").toString();
							}
							else {
								editor = "false";
							}
						}
						if (_childValue.containsKey("time")) {
							time = _childValue.get("time").toString();
						}
						if (_childValue.containsKey("verified")) {
							if (_childValue.get("verified").toString().equals("true")) {
								verified = _childValue.get("verified").toString();
							}
							else {
								verified = "false";
							}
						}
					}
				}
				else {
					
				}
			}
			
			@Override
			public void onChildChanged(DataSnapshot _param1, String _param2) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				SketchwareUtil.showMessage(getApplicationContext(), "update success");
			}
			
			@Override
			public void onChildMoved(DataSnapshot _param1, String _param2) {
				
			}
			
			@Override
			public void onChildRemoved(DataSnapshot _param1) {
				GenericTypeIndicator<HashMap<String, Object>> _ind = new GenericTypeIndicator<HashMap<String, Object>>() {};
				final String _childKey = _param1.getKey();
				final HashMap<String, Object> _childValue = _param1.getValue(_ind);
				
			}
			
			@Override
			public void onCancelled(DatabaseError _param1) {
				final int _errorCode = _param1.getCode();
				final String _errorMessage = _param1.getMessage();
				
			}
		};
		data1.addChildEventListener(_data1_child_listener);
		
		_swb_uploads_upload_progress_listener = new OnProgressListener<UploadTask.TaskSnapshot>() {
			@Override
			public void onProgress(UploadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_swb_uploads_download_progress_listener = new OnProgressListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onProgress(FileDownloadTask.TaskSnapshot _param1) {
				double _progressValue = (100.0 * _param1.getBytesTransferred()) / _param1.getTotalByteCount();
				
			}
		};
		
		_swb_uploads_upload_success_listener = new OnCompleteListener<Uri>() {
			@Override
			public void onComplete(Task<Uri> _param1) {
				final String _downloadUrl = _param1.getResult().toString();
				project_url = _downloadUrl;
				_telegramLoaderDialog(false);
			}
		};
		
		_swb_uploads_download_success_listener = new OnSuccessListener<FileDownloadTask.TaskSnapshot>() {
			@Override
			public void onSuccess(FileDownloadTask.TaskSnapshot _param1) {
				final long _totalByteCount = _param1.getTotalByteCount();
				
			}
		};
		
		_swb_uploads_delete_success_listener = new OnSuccessListener() {
			@Override
			public void onSuccess(Object _param1) {
				
			}
		};
		
		_swb_uploads_failure_listener = new OnFailureListener() {
			@Override
			public void onFailure(Exception _param1) {
				final String _message = _param1.getMessage();
				
			}
		};
		
		auth_updateEmailListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_updatePasswordListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_emailVerificationSentListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_deleteUserListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_phoneAuthListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		auth_updateProfileListener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		auth_googleSignInListener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> task) {
				final boolean _success = task.isSuccessful();
				final String _errorMessage = task.getException() != null ? task.getException().getMessage() : "";
				
			}
		};
		
		_auth_create_user_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_sign_in_listener = new OnCompleteListener<AuthResult>() {
			@Override
			public void onComplete(Task<AuthResult> _param1) {
				final boolean _success = _param1.isSuccessful();
				final String _errorMessage = _param1.getException() != null ? _param1.getException().getMessage() : "";
				
			}
		};
		
		_auth_reset_password_listener = new OnCompleteListener<Void>() {
			@Override
			public void onComplete(Task<Void> _param1) {
				final boolean _success = _param1.isSuccessful();
				
			}
		};
	}
	
	private void initializeLogic() {
		PATH_SKETCHWARE = FileUtil.getExternalStorageDir().concat("/.sketchware/");
		PATH_HIDE_SKETCHLIB = FileUtil.getExternalStorageDir().concat("/.SKETCH SMART STORE/");
		PATH_SKETCHLIB = FileUtil.getExternalStorageDir().concat("/download/Sketch Smart Store/");
		if (!FileUtil.isExistFile(PATH_SKETCHWARE)) {
			FileUtil.makeDir(PATH_SKETCHWARE);
		}
		if (!FileUtil.isExistFile(PATH_HIDE_SKETCHLIB)) {
			FileUtil.makeDir(PATH_HIDE_SKETCHLIB);
		}
		if (!FileUtil.isExistFile(PATH_SKETCHLIB)) {
			FileUtil.makeDir(PATH_SKETCHLIB);
		}
		ProjectType = "SK";
		textview13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		tit.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		des.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		whatne.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview_category.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		textview12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/poppins_medium.ttf"), 0);
		_ripple(imageview6);
		_ripple(imageview7);
		_ripple(s1);
		_ripple(s2);
		_ripple(s3);
		_ripple(s4);
		_ripple(s5);
	}
	
	@Override
	protected void onActivityResult(int _requestCode, int _resultCode, Intent _data) {
		super.onActivityResult(_requestCode, _resultCode, _data);
		
		switch (_requestCode) {
			case REQ_CD_SC1:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				s1path = _filePath.get((int)(0));
				s1name = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				Glide.with(getApplicationContext()).load(Uri.parse(_filePath.get((int)(0)))).into(s1);
				up1.child(s1name).putFile(Uri.fromFile(new File(s1path))).addOnFailureListener(_up1_failure_listener).addOnProgressListener(_up1_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return up1.child(s1name).getDownloadUrl();
					}}).addOnCompleteListener(_up1_upload_success_listener);
				_telegramLoaderDialog(true);
			}
			else {
				
			}
			break;
			
			case REQ_CD_SC2:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				s2path = _filePath.get((int)(0));
				s2name = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				Glide.with(getApplicationContext()).load(Uri.parse(_filePath.get((int)(0)))).into(s2);
				up2.child(s2name).putFile(Uri.fromFile(new File(s2path))).addOnFailureListener(_up2_failure_listener).addOnProgressListener(_up2_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return up2.child(s2name).getDownloadUrl();
					}}).addOnCompleteListener(_up2_upload_success_listener);
				_telegramLoaderDialog(true);
			}
			else {
				
			}
			break;
			
			case REQ_CD_SC3:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				s3path = _filePath.get((int)(0));
				s3name = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				Glide.with(getApplicationContext()).load(Uri.parse(_filePath.get((int)(0)))).into(s3);
				up3.child(s3name).putFile(Uri.fromFile(new File(s3path))).addOnFailureListener(_up3_failure_listener).addOnProgressListener(_up3_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return up3.child(s3name).getDownloadUrl();
					}}).addOnCompleteListener(_up3_upload_success_listener);
				_telegramLoaderDialog(true);
			}
			else {
				
			}
			break;
			
			case REQ_CD_SC4:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				s4path = _filePath.get((int)(0));
				s4name = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				Glide.with(getApplicationContext()).load(Uri.parse(_filePath.get((int)(0)))).into(s4);
				up4.child(s4name).putFile(Uri.fromFile(new File(s4path))).addOnFailureListener(_up4_failure_listener).addOnProgressListener(_up4_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return up4.child(s4name).getDownloadUrl();
					}}).addOnCompleteListener(_up4_upload_success_listener);
				_telegramLoaderDialog(true);
			}
			else {
				
			}
			break;
			
			case REQ_CD_SC5:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				s5path = _filePath.get((int)(0));
				s5name = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				Glide.with(getApplicationContext()).load(Uri.parse(_filePath.get((int)(0)))).into(s5);
				up5.child(s5name).putFile(Uri.fromFile(new File(s5path))).addOnFailureListener(_up5_failure_listener).addOnProgressListener(_up5_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return up5.child(s5name).getDownloadUrl();
					}}).addOnCompleteListener(_up5_upload_success_listener);
				_telegramLoaderDialog(true);
			}
			else {
				
			}
			break;
			
			case REQ_CD_P_ICON:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				iconpath = _filePath.get((int)(0));
				iconname = Uri.parse(Uri.parse(_filePath.get((int)(0))).getLastPathSegment()).getLastPathSegment();
				Glide.with(getApplicationContext()).load(Uri.parse(_filePath.get((int)(0)))).into(icon);
				iconup.child(iconname).putFile(Uri.fromFile(new File(iconpath))).addOnFailureListener(_iconup_failure_listener).addOnProgressListener(_iconup_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return iconup.child(iconname).getDownloadUrl();
					}}).addOnCompleteListener(_iconup_upload_success_listener);
				_telegramLoaderDialog(true);
			}
			else {
				
			}
			break;
			
			case REQ_CD_SWB:
			if (_resultCode == Activity.RESULT_OK) {
				ArrayList<String> _filePath = new ArrayList<>();
				if (_data != null) {
					if (_data.getClipData() != null) {
						for (int _index = 0; _index < _data.getClipData().getItemCount(); _index++) {
							ClipData.Item _item = _data.getClipData().getItemAt(_index);
							_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _item.getUri()));
						}
					}
					else {
						_filePath.add(FileUtil.convertUriToFilePath(getApplicationContext(), _data.getData()));
					}
				}
				if (_filePath.get((int)(0)).endsWith(".swb")) {
					projectpath = _filePath.get((int)(0));
					projectname = Uri.parse(projectpath).getLastPathSegment();
					tit.setText(projectname);
					java.io.File file = new java.io.File(path);
					file_size = String.valueOf(file.length());
					_CalculateSize(Double.parseDouble(file_size));
					swb_uploads.child(projectname).putFile(Uri.fromFile(new File(projectpath))).addOnFailureListener(_swb_uploads_failure_listener).addOnProgressListener(_swb_uploads_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
						@Override
						public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
							return swb_uploads.child(projectname).getDownloadUrl();
						}}).addOnCompleteListener(_swb_uploads_upload_success_listener);
					_telegramLoaderDialog(true);
				}
				else {
					SketchwareUtil.showMessage(getApplicationContext(), "please add .swb file not allowed the any file only pick .swb");
				}
			}
			else {
				
			}
			break;
			default:
			break;
		}
	}
	
	
	@Override
	public void onBackPressed() {
		finish();
	}
	public void _FilePickerDialog(final String _title, final String _message, final String _format) {
		DialogProperties fpp = new DialogProperties();
		fpp.selection_mode = DialogConfigs.SINGLE_MODE;
		fpp.selection_type = DialogConfigs.FILE_SELECT;
		fpp.root = new java.io.File(FileUtil.getExternalStorageDir());
		fpp.error_dir = new java.io.File(FileUtil.getExternalStorageDir());
		fpp.offset = new java.io.File(FileUtil.getExternalStorageDir());
		fpp.extensions = new String[] {_format};
		fp = new FilePickerDialog(UploadProjectActivity.this,fpp);
		fp.setTitle(_title);
		fp.setPositiveBtnName(_message);
		fp.setNegativeBtnName("Cancel");
		fp.setDialogSelectionListener(new DialogSelectionListener() {
			@Override public void onSelectedFilePaths(String[] files) {
				projectpath = Arrays.asList(files).get((int) 0).toString();
				projectname = Uri.parse(projectpath).getLastPathSegment();
				tit.setText(projectname);
				java.io.File file = new java.io.File(path);
				file_size = String.valueOf(file.length());
				_CalculateSize(Double.parseDouble(file_size));
				swb_uploads.child("package.swb.files.".concat(projectname)).putFile(Uri.fromFile(new File("swb.".concat(projectpath)))).addOnFailureListener(_swb_uploads_failure_listener).addOnProgressListener(_swb_uploads_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
					@Override
					public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
						return swb_uploads.child("package.swb.files.".concat(projectname)).getDownloadUrl();
					}}).addOnCompleteListener(_swb_uploads_upload_success_listener);
				_telegramLoaderDialog(true);
			} 
		});
		fp.show();
	}
	
	
	public void _ProjectTypeDialog() {
		AlertDialog.Builder dialog = new AlertDialog.Builder(this);
		dialog.setTitle("Select Project Type");
		String[] items = {
			"Sketchware Project",
			"Sketchware Pro",
			
		};
		int checkedItem = (int)(typeID);
		dialog.setSingleChoiceItems(items, checkedItem, new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialog, int which) {
				switch (which) {
					case 0:
					ProjectType = "SK";
					break;
					case 1:
					ProjectType = "SW";
					break;
				}
			}
		});
		dialog.setNegativeButton("CANCEL", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				
			}
		});
		dialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface _dialog, int _which) {
				if (ProjectType.equals("SK")) {
					textview11.setText("Sketchware Project");
					typeID = 0;
				}
				else {
					if (ProjectType.equals("SW")) {
						textview11.setText("Sketchware Pro");
						typeID = 1;
					}
					else {
						
					}
				}
			}
		});
		AlertDialog alert = dialog.create();
		alert.setCanceledOnTouchOutside(false);
		alert.show();
	}
	
	
	public void _oops() {
		final AlertDialog dialog1 = new AlertDialog.Builder(UploadProjectActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.custom4,null); 
		dialog1.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
		dialog1.setView(inflate);
		LinearLayout bg = (LinearLayout) inflate.findViewById(R.id.bg);
		TextView t1 = (TextView) inflate.findViewById(R.id.t1);
		
		TextView t2 = (TextView) inflate.findViewById(R.id.t2);
		
		TextView t3 = (TextView) inflate.findViewById(R.id.t3);
		
		TextView t4 = (TextView) inflate.findViewById(R.id.t4);
		
		TextView t5 = (TextView) inflate.findViewById(R.id.t5);
		
		TextView t6 = (TextView) inflate.findViewById(R.id.t6);
		
		TextView t7 = (TextView) inflate.findViewById(R.id.t7);
		
		TextView t8 = (TextView) inflate.findViewById(R.id.t8);
		
		TextView t9 = (TextView) inflate.findViewById(R.id.t9);
		
		TextView t10 = (TextView) inflate.findViewById(R.id.t10);
		
		TextView t11 = (TextView) inflate.findViewById(R.id.t11);
		
		TextView t12 = (TextView) inflate.findViewById(R.id.t12);
		
		TextView t13 = (TextView) inflate.findViewById(R.id.t13);
		
		TextView t14 = (TextView) inflate.findViewById(R.id.t14);
		
		TextView t15 = (TextView) inflate.findViewById(R.id.t15);
		
		TextView t16 = (TextView) inflate.findViewById(R.id.t16);
		
		TextView t17 = (TextView) inflate.findViewById(R.id.t17);
		ImageView i1 = (ImageView) inflate.findViewById(R.id.i1);
		
		ImageView i2 = (ImageView) inflate.findViewById(R.id.i2);
		
		ImageView i3 = (ImageView) inflate.findViewById(R.id.i3);
		
		ImageView i4 = (ImageView) inflate.findViewById(R.id.i4);
		
		ImageView i5 = (ImageView) inflate.findViewById(R.id.i5);
		
		ImageView i6 = (ImageView) inflate.findViewById(R.id.i6);
		
		ImageView i7 = (ImageView) inflate.findViewById(R.id.i7);
		
		ImageView i8 = (ImageView) inflate.findViewById(R.id.i8);
		
		ImageView i9 = (ImageView) inflate.findViewById(R.id.i9);
		
		ImageView i10 = (ImageView) inflate.findViewById(R.id.i10);
		
		ImageView i11 = (ImageView) inflate.findViewById(R.id.i11);
		
		ImageView i12 = (ImageView) inflate.findViewById(R.id.i12);
		
		ImageView i13 = (ImageView) inflate.findViewById(R.id.i13);
		
		ImageView i14 = (ImageView) inflate.findViewById(R.id.i14);
		
		ImageView i15 = (ImageView) inflate.findViewById(R.id.i15);
		
		ImageView i16 = (ImageView) inflate.findViewById(R.id.i16);
		LinearLayout b1 = (LinearLayout) inflate.findViewById(R.id.b1);
		
		LinearLayout b2 = (LinearLayout) inflate.findViewById(R.id.b2);
		
		LinearLayout b3 = (LinearLayout) inflate.findViewById(R.id.b3);
		
		LinearLayout b4 = (LinearLayout) inflate.findViewById(R.id.b4);
		
		LinearLayout b5 = (LinearLayout) inflate.findViewById(R.id.b5);
		
		LinearLayout b6 = (LinearLayout) inflate.findViewById(R.id.b6);
		
		LinearLayout b7 = (LinearLayout) inflate.findViewById(R.id.b7);
		
		LinearLayout b8 = (LinearLayout) inflate.findViewById(R.id.b8);
		
		LinearLayout b9 = (LinearLayout) inflate.findViewById(R.id.b9);
		
		LinearLayout b10 = (LinearLayout) inflate.findViewById(R.id.b10);
		
		LinearLayout b11 = (LinearLayout) inflate.findViewById(R.id.b11);
		
		LinearLayout b12 = (LinearLayout) inflate.findViewById(R.id.b12);
		
		LinearLayout b13 = (LinearLayout) inflate.findViewById(R.id.b13);
		
		LinearLayout b14 = (LinearLayout) inflate.findViewById(R.id.b14);
		
		LinearLayout b15 = (LinearLayout) inflate.findViewById(R.id.b15);
		
		LinearLayout b16 = (LinearLayout) inflate.findViewById(R.id.b16);
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t2.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t5.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t6.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t7.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t8.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t9.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t10.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t11.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t12.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t13.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t14.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t15.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t16.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		t17.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/raleway_light.ttf"), 0);
		i1.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i2.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i3.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i4.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i5.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i6.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i7.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i8.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i9.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i10.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i11.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i12.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i13.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i14.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i15.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		i16.setColorFilter(0xFF2196F3, PorterDuff.Mode.MULTIPLY);
		_rippleRoundStroke(bg, "#FFFFFF", "#000000", 25, 0, "#00000000");
		_rippleRoundStroke(b1, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b2, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b3, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b4, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b5, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b6, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b7, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b8, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b9, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b10, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b11, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b12, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b13, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b14, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b15, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		_rippleRoundStroke(b16, "#FFFFFF", "#E0E0E0", 0, 0, "#00000000");
		b1.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Books & Reference");
				dialog1.dismiss();
			}
		});
		b2.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Business");
				dialog1.dismiss();
			}
		});
		b3.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Communication");
				dialog1.dismiss();
			}
		});
		b4.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Education");
				dialog1.dismiss();
			}
		});
		b5.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Entertainment");
				dialog1.dismiss();
			}
		});
		b6.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Example & Tutorial");
				dialog1.dismiss();
			}
		});
		b7.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Games");
				dialog1.dismiss();
			}
		});
		b8.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Multi-Device");
				dialog1.dismiss();
			}
		});
		b9.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Music & Audio");
				dialog1.dismiss();
			}
		});
		b10.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Other");
				dialog1.dismiss();
			}
		});
		b11.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Photographic");
				dialog1.dismiss();
			}
		});
		b12.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Productivity");
				dialog1.dismiss();
			}
		});
		b13.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Social");
				dialog1.dismiss();
			}
		});
		b14.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Tools");
				dialog1.dismiss();
			}
		});
		b15.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Ui & UX");
				dialog1.dismiss();
			}
		});
		b16.setOnClickListener(new View.OnClickListener(){ public void onClick(View v){ 
				textview_category.setText("Videography");
				dialog1.dismiss();
			}
		});
		dialog1.setCancelable(false);
		dialog1.show();
	}
	
	
	public void _rippleRoundStroke(final View _view, final String _focus, final String _pressed, final double _round, final double _stroke, final String _strokeclr) {
		android.graphics.drawable.GradientDrawable GG = new android.graphics.drawable.GradientDrawable();
		GG.setColor(Color.parseColor(_focus));
		GG.setCornerRadius((float)_round);
		GG.setStroke((int) _stroke,
		Color.parseColor("#" + _strokeclr.replace("#", "")));
		android.graphics.drawable.RippleDrawable RE = new android.graphics.drawable.RippleDrawable(new android.content.res.ColorStateList(new int[][]{new int[]{}}, new int[]{ Color.parseColor(_pressed)}), GG, null);
		_view.setBackground(RE);
	}
	
	
	public void _Load_Projects() {
		temp_str1.clear();
		temp_listmap1.clear();
		temp_map1.clear();
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/"), temp_str1);
		Collections.sort(temp_str1, String.CASE_INSENSITIVE_ORDER);
		number = 0;
		for(int _repeat18 = 0; _repeat18 < (int)(temp_str1.size()); _repeat18++) {
			if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(Uri.parse(temp_str1.get((int)(number))).getLastPathSegment().concat("/project"))))) {
				try {
					javax.crypto.Cipher instance = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
					byte[] bytes = "sketchwaresecure".getBytes();
					instance.init(2, new javax.crypto.spec.SecretKeySpec(bytes, "AES"), new javax.crypto.spec.IvParameterSpec(bytes));
					java.io.RandomAccessFile randomAccessFile = new java.io.RandomAccessFile(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list/".concat(Uri.parse(temp_str1.get((int)(number))).getLastPathSegment().concat("/project"))), "r");
					byte[] bArr = new byte[((int) randomAccessFile.length())];
					randomAccessFile.readFully(bArr);
					temp_decrypted = new String(instance.doFinal(bArr));
					temp_map1 = new HashMap<>();
					temp_map1 = new Gson().fromJson(temp_decrypted, new TypeToken<HashMap<String, Object>>(){}.getType());
					temp_listmap1.add(temp_map1);
				} catch(Exception e) {
					showMessage(e.toString());
				}
			}
			number++;
		}
		Collections.reverse(temp_listmap1);
	}
	
	
	public void _New_ID_Generation() {
		FileUtil.listDir(FileUtil.getExternalStorageDir().concat("/.sketchware/mysc/list"), temp);
		Collections.sort(temp, String.CASE_INSENSITIVE_ORDER);
		if (temp.size() == 0) {
			new_id = "601";
		}
		else {
			try {
				new_id = String.valueOf((long)(Double.parseDouble(Uri.parse(temp.get((int)(temp.size() - 1))).getLastPathSegment()) + 1));
			} catch(Exception e) {
			}
		}
	}
	
	
	public void _UnZip(final String _fileZip, final String _destDir) {
		try
		{
			java.io.File outdir = new java.io.File(_destDir);
			java.util.zip.ZipInputStream zin = new java.util.zip.ZipInputStream(new java.io.FileInputStream(_fileZip));
			java.util.zip.ZipEntry entry;
			String name, dir;
			while ((entry = zin.getNextEntry()) != null)
			{
				name = entry.getName();
				if(entry.isDirectory())
				{
					mkdirs(outdir, name);
					continue;
				}
				
				/* this part is necessary because file entry can come before
* directory entry where is file located
* i.e.:
* /foo/foo.txt
* /foo/
*/
				
				dir = dirpart(name);
				if(dir != null)
				mkdirs(outdir, dir);
				
				extractFile(zin, outdir, name);
			}
			zin.close();
		}
		catch (java.io.IOException e)
		{
			e.printStackTrace();
		}
	}
	private static void extractFile(java.util.zip.ZipInputStream in, java.io.File outdir, String name) throws java.io.IOException
	{
		byte[] buffer = new byte[4096];
		java.io.BufferedOutputStream out = new java.io.BufferedOutputStream(new java.io.FileOutputStream(new java.io.File(outdir, name)));
		int count = -1;
		while ((count = in.read(buffer)) != -1)
		out.write(buffer, 0, count);
		out.close();
	}
	
	private static void mkdirs(java.io.File outdir, String path)
	{
		java.io.File d = new java.io.File(outdir, path);
		if(!d.exists())
		d.mkdirs();
	}
	
	private static String dirpart(String name)
	{
		int s = name.lastIndexOf(java.io.File.separatorChar);
		return s == -1 ? null : name.substring(0, s);
	}
	
	
	public void _Decrypt(final String _path) {
		try {
			javax.crypto.Cipher instance = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] bytes = "sketchwaresecure".getBytes();
			instance.init(2, new javax.crypto.spec.SecretKeySpec(bytes, "AES"), new javax.crypto.spec.IvParameterSpec(bytes));
			java.io.RandomAccessFile randomAccessFile = new java.io.RandomAccessFile(_path, "r");
			byte[] bArr = new byte[((int) randomAccessFile.length())];
			randomAccessFile.readFully(bArr);
			temp_decrypted = new String(instance.doFinal(bArr));
		} catch(Exception e) {
			showMessage(e.toString());
		}
	}
	
	
	public void _Encrypt(final String _path) {
		try {
			javax.crypto.Cipher instance = javax.crypto.Cipher.getInstance("AES/CBC/PKCS5Padding");
			byte[] bytes = "sketchwaresecure".getBytes();
			instance.init(1, new javax.crypto.spec.SecretKeySpec(bytes, "AES"), new javax.crypto.spec.IvParameterSpec(bytes));
			new java.io.RandomAccessFile(_path, "rw").write(instance.doFinal(temp_decrypted.getBytes()));
		} catch(Exception e) {
			showMessage(e.toString());
		}
	}
	
	
	public void _Copy(final String _F, final String _T) {
		FileUtil.makeDir(_T.concat("/"));
		copy_list.clear();
		FileUtil.listDir(_F.concat("/"), copy_list);
		number = 0;
		for(int _repeat11 = 0; _repeat11 < (int)(copy_list.size()); _repeat11++) {
			if (FileUtil.isFile(copy_list.get((int)(number)))) {
				FileUtil.copyFile(copy_list.get((int)(number)), _T.concat("/".concat(Uri.parse(copy_list.get((int)(number))).getLastPathSegment())));
			}
			number++;
		}
	}
	
	
	public void _Show_Projects_Dialog() {
		final AlertDialog p_dialog = new AlertDialog.Builder(UploadProjectActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.dialog_cus, null);
		p_dialog.setView(inflate);
		
		LinearLayout linear1 = (LinearLayout)inflate.findViewById(R.id.linear1);
		
		TextView textview1 = (TextView)inflate.findViewById(R.id.textview1);
		textview1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		textview1.setText("Select Project");
		
		ImageView imageview1 = (ImageView)inflate.findViewById(R.id.imageview1);
		
		final ListView listView2 = new ListView(UploadProjectActivity.this);
		listView2.setDivider(null); 
		listView2.setDividerHeight(0);
		listView2.setLayoutParams(new GridView.LayoutParams(GridLayout.LayoutParams.MATCH_PARENT, GridLayout.LayoutParams.WRAP_CONTENT));
		listView2.setAdapter(new List1Adapter(temp_listmap1));
		((BaseAdapter)listView2.getAdapter()).notifyDataSetChanged();
		linear1.addView(listView2);
		
		imageview1.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				p_dialog.dismiss();
			}
		});
		
		listView2.setOnItemClickListener(new AdapterView.OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView parent, View view, int _pos, long id) {
				p_dialog.dismiss();
				_SHARE(_pos, temp_listmap1);
			}});
		
		p_dialog.show();
	}
	private ListView listView2;
	public class List1Adapter extends
	BaseAdapter {
		ArrayList<HashMap<String, Object>> _data;
		public List1Adapter(ArrayList<HashMap<String, Object>> _arr) {
			_data = _arr;
		}
		@Override
		public int getCount() {
			return _data.size();
		}
		@Override
		public HashMap<String, Object> getItem(int _index) {
			return _data.get(_index);
		}
		@Override
		public long getItemId(int _index) {
			return _index;
		}
		@Override
		public View getView(final int _position, View _view, ViewGroup _viewGroup) {
			LayoutInflater _inflater = (LayoutInflater)getBaseContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			View _v = _view;
			if (_v == null) {
				_v = _inflater.inflate(R.layout.project_cus, null);
			}
			
			final LinearLayout linear1 = (LinearLayout) _v.findViewById(R.id.linear1);
			
			final ImageView icon = (ImageView) _v.findViewById(R.id.icon);
			
			final TextView title = (TextView) _v.findViewById(R.id.title);
			
			final TextView pack = (TextView) _v.findViewById(R.id.pack);
			
			final TextView num = (TextView) _v.findViewById(R.id.num);
			
			if (_data.get((int)_position).containsKey("sc_id")) {
				if (_data.get((int)_position).containsKey("my_app_name")) {
					title.setText(_data.get((int)_position).get("my_app_name").toString());
				}
				
				if (_data.get((int)_position).containsKey("my_sc_pkg_name")) {
					pack.setText(_data.get((int)_position).get("my_sc_pkg_name").toString());
				}
				if (_data.get((int)_position).containsKey("sc_id")) {
					num.setText(_data.get((int)_position).get("sc_id").toString());
				}
				if (_data.get((int)_position).containsKey("custom_icon")) {
					if (_data.get((int)_position).get("custom_icon").toString().equals("true")) {
						if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_data.get((int)_position).get("sc_id").toString().concat("/icon.png"))))) {
							if (BitmapFactory.decodeFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_data.get((int)_position).get("sc_id").toString().concat("/icon.png")))) != null) {	icon.setImageBitmap(FileUtil.decodeSampleBitmapFromPath(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_data.get((int)_position).get("sc_id").toString().concat("/icon.png"))), 1024, 1024));
							}else {
								icon.setImageResource(R.drawable.android_icon);
							}
						}else {
							icon.setImageResource(R.drawable.android_icon);
						}
					} else {
						icon.setImageResource(R.drawable.android_icon);
					}
				} else {
					icon.setImageResource(R.drawable.android_icon);
				}
				linear1.setVisibility(View.VISIBLE);
			}else {
				linear1.setVisibility(View.GONE);
			}
			return _v;
		}
	}
	
	
	public void _zip(final String _source, final String _destination) {
		FileUtil.writeFile("Don't Remove it Thanks.\nModified By: Smart India Gaming", "This Block Added for Manage Permission");
		try {
			java.util.zip.ZipOutputStream os = new java.util.zip.ZipOutputStream(new java.io.FileOutputStream(_destination));
					zip(os, _source, null);
					os.close();
		}
		
		catch(java.io.IOException e) {}
	}
	private void zip(java.util.zip.ZipOutputStream os, String filePath, String name) throws java.io.IOException
		{
				java.io.File file = new java.io.File(filePath);
				java.util.zip.ZipEntry entry = new java.util.zip.ZipEntry((name != null ? name + java.io.File.separator : "") + file.getName() + (file.isDirectory() ? java.io.File.separator : ""));
				os.putNextEntry(entry);
				
				if(file.isFile()) {
						java.io.InputStream is = new java.io.FileInputStream(file);
						int size = is.available();
						byte[] buff = new byte[size];
						int len = is.read(buff);
						os.write(buff, 0, len);
						return;
				}
				
				java.io.File[] fileArr = file.listFiles();
				for(java.io.File subFile : fileArr) {
						zip(os, subFile.getAbsolutePath(), entry.getName());
				}
	}
	
	
	public void _SHARE(final double _position, final ArrayList<HashMap<String, Object>> _listmap) {
		_telegramLoaderDialog(true);
		FileUtil.makeDir(PATH_HIDE_SKETCHLIB.concat("temp/data/"));
		FileUtil.makeDir(PATH_HIDE_SKETCHLIB.concat("temp/list/"));
		FileUtil.makeDir(PATH_HIDE_SKETCHLIB.concat("temp/fonts/"));
		FileUtil.makeDir(PATH_HIDE_SKETCHLIB.concat("temp/icons/"));
		FileUtil.makeDir(PATH_HIDE_SKETCHLIB.concat("temp/images/"));
		FileUtil.makeDir(PATH_HIDE_SKETCHLIB.concat("temp/sounds/"));
		FileUtil.makeDir(PATH_SKETCHLIB.concat("temp/"));
		_Copy(PATH_SKETCHWARE.concat("data/".concat(_listmap.get((int)_position).get("sc_id").toString())), PATH_HIDE_SKETCHLIB.concat("temp/data/"));
		_Copy(PATH_SKETCHWARE.concat("mysc/list/".concat(_listmap.get((int)_position).get("sc_id").toString())), PATH_HIDE_SKETCHLIB.concat("temp/list/"));
		_Copy(PATH_SKETCHWARE.concat("resources/fonts/".concat(_listmap.get((int)_position).get("sc_id").toString())), PATH_HIDE_SKETCHLIB.concat("temp/fonts/"));
		_Copy(PATH_SKETCHWARE.concat("resources/icons/".concat(_listmap.get((int)_position).get("sc_id").toString())), PATH_HIDE_SKETCHLIB.concat("temp/icons/"));
		_Copy(PATH_SKETCHWARE.concat("resources/images/".concat(_listmap.get((int)_position).get("sc_id").toString())), PATH_HIDE_SKETCHLIB.concat("temp/images/"));
		_Copy(PATH_SKETCHWARE.concat("resources/sounds/".concat(_listmap.get((int)_position).get("sc_id").toString())), PATH_HIDE_SKETCHLIB.concat("temp/sounds/"));
		_zip(PATH_HIDE_SKETCHLIB.concat("temp"), PATH_SKETCHLIB.concat("temp/temp.zip"));
		timer = new TimerTask() {
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						FileUtil.deleteFile(PATH_HIDE_SKETCHLIB.concat("temp"));
						_telegramLoaderDialog(false);
						up_edit = (_listmap.get((int)_position).get("my_app_name").toString());;
						if (_listmap.get((int)_position).containsKey("custom_icon")) {
							if (_listmap.get((int)_position).get("custom_icon").toString().equals("true")) {
								if (FileUtil.isExistFile(FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_listmap.get((int)_position).get("sc_id").toString().concat("/icon.png"))))) {
									icon_path = FileUtil.getExternalStorageDir().concat("/.sketchware/resources/icons/".concat(_listmap.get((int)_position).get("sc_id").toString().concat("/icon.png")));
									if (BitmapFactory.decodeFile(icon_path) != null) {
										up_icon = icon_path;
									}
									else {
										up_icon = "";
									}
								}
								else {
									up_icon = "";
								}
							}
							else {
								up_icon = "";
							}
						}
						else {
							up_icon = "";
						}
						if (up_edit.trim().equals("")) {
							SketchwareUtil.showMessage(getApplicationContext(), "project title is empty");
						}
						else {
							tit.setText(up_edit);
							path = PATH_SKETCHLIB.concat("temp/temp.zip");
							java.io.File file = new java.io.File(path);
							file_size = String.valueOf(file.length());
							_CalculateSize(Double.parseDouble(file_size));
							project.child("project/".concat(project_key.concat(".zip"))).putFile(Uri.fromFile(new File(PATH_SKETCHLIB.concat("temp/temp.zip")))).addOnFailureListener(_project_failure_listener).addOnProgressListener(_project_upload_progress_listener).continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
								@Override
								public Task<Uri> then(Task<UploadTask.TaskSnapshot> task) throws Exception {
									return project.child("project/".concat(project_key.concat(".zip"))).getDownloadUrl();
								}}).addOnCompleteListener(_project_upload_success_listener);
							_telegramLoaderDialog(true);
						}
					}
				});
			}
		};
		_timer.schedule(timer, (int)(3000));
	}
	
	
	public void _telegramLoaderDialog(final boolean _visibility) {
		if (_visibility) {
			isVisible = true;
			if (coreprog == null){
				coreprog = new ProgressDialog(this);
				coreprog.setCancelable(false);
				coreprog.setCanceledOnTouchOutside(false);
				
				coreprog.requestWindowFeature(Window.FEATURE_NO_TITLE);  coreprog.getWindow().setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.TRANSPARENT));
				
			}
			coreprog.show();
			coreprog.setContentView(R.layout.loading);
			
			
			LinearLayout linear2 = (LinearLayout)coreprog.findViewById(R.id.linear2);
			
			LinearLayout background = (LinearLayout)coreprog.findViewById(R.id.background);
			
			LinearLayout layout_progress = (LinearLayout)coreprog.findViewById(R.id.layout_progress);
			
			android.graphics.drawable.GradientDrawable gd = new android.graphics.drawable.GradientDrawable(); 
			gd.setColor(Color.parseColor("#EEEEEE")); /* color */
			gd.setCornerRadius(40); /* radius */
			gd.setStroke(0, Color.WHITE); /* stroke heigth and color */
			linear2.setBackground(gd);
			
			RadialProgressView progress = new RadialProgressView(this);
			layout_progress.addView(progress);
		}
		else {
			isVisible = false;
			if (coreprog != null){
				coreprog.dismiss();
			}
		}
	}
	private ProgressDialog coreprog;
	{
	}
	
	
	public void _CalculateSize(final double _fileSize) {
		B = 1024;
		KB = B * B;
		MB = B * (B * B);
		GB = B * (B * (B * B));
		TB = B * (B * (B * (B * B)));
		PB = B * (B * (B * (B * (B * B))));
		if (_fileSize < B) {
			returnedSize = String.valueOf((long)(_fileSize)).concat(" B");
		}
		else {
			if (_fileSize < KB) {
				returnedSize = new DecimalFormat("0.00").format(_fileSize / B).concat(" KB");
			}
			else {
				if (_fileSize < MB) {
					returnedSize = new DecimalFormat("0.00").format(_fileSize / KB).concat(" MB");
				}
				else {
					if (_fileSize < GB) {
						returnedSize = new DecimalFormat("0.00").format(_fileSize / MB).concat(" GB");
					}
					else {
						if (_fileSize < TB) {
							returnedSize = new DecimalFormat("0.00").format(_fileSize / GB).concat(" TB");
						}
						else {
							if (_fileSize < PB) {
								returnedSize = new DecimalFormat("0.00").format(_fileSize / TB).concat(" PB");
							}
						}
					}
				}
			}
		}
	}
	
	
	public void _CustomDialog(final String _mesg, final String _title, final String _canceltext, final String _done) {
		final AlertDialog UploadSuccessDialog = new AlertDialog.Builder(UploadProjectActivity.this).create();
		View inflate = getLayoutInflater().inflate(R.layout.dialog,null); UploadSuccessDialog.setView(inflate);
		LinearLayout l1 = (LinearLayout)inflate.findViewById(R.id.l1);
		LinearLayout l3 = (LinearLayout)inflate.findViewById(R.id.l3);
		LinearLayout l4 = (LinearLayout)inflate.findViewById(R.id.l4);
		ScrollView hs = (ScrollView)inflate.findViewById(R.id.hs);
		TextView t1 = (TextView)inflate.findViewById(R.id.t1);
		TextView m1 = (TextView)inflate.findViewById(R.id.m1);
		TextView t3 = (TextView)inflate.findViewById(R.id.t3);
		TextView t4 = (TextView)inflate.findViewById(R.id.t4);
		l1.setBackground(new GradientDrawable() { public GradientDrawable getIns(int a, int b) { this.setCornerRadius(a); this.setColor(b); return this; } }.getIns((int)30, 0xFFFFFFFF));
		t1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		m1.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		t3.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		t4.setTypeface(Typeface.createFromAsset(getAssets(),"fonts/google_sans_bold.ttf"), 0);
		t3.setTextColor(0xFFF44336);
		t4.setTextColor(0xFF2962FF);
		t1.setText(_title);
		m1.setText(_mesg);
		t3.setText(_canceltext);
		t4.setText(_done);
		t4.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View _view) {
						finish();
				}
		});
		UploadSuccessDialog.setCancelable(true);
		UploadSuccessDialog.show();
	}
	
	
	public void _ripple(final View _view) {
		
		int[] attrs = new int[]{android.R.attr.selectableItemBackgroundBorderless};
		android.content.res.TypedArray typedArray = this.obtainStyledAttributes(attrs);
		int backgroundResource = typedArray.getResourceId(0, 0); _view.setBackgroundResource(backgroundResource);
		_view.setClickable(true);
	}
	
	
	@Deprecated
	public void showMessage(String _s) {
		Toast.makeText(getApplicationContext(), _s, Toast.LENGTH_SHORT).show();
	}
	
	@Deprecated
	public int getLocationX(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[0];
	}
	
	@Deprecated
	public int getLocationY(View _v) {
		int _location[] = new int[2];
		_v.getLocationInWindow(_location);
		return _location[1];
	}
	
	@Deprecated
	public int getRandom(int _min, int _max) {
		Random random = new Random();
		return random.nextInt(_max - _min + 1) + _min;
	}
	
	@Deprecated
	public ArrayList<Double> getCheckedItemPositionsToArray(ListView _list) {
		ArrayList<Double> _result = new ArrayList<Double>();
		SparseBooleanArray _arr = _list.getCheckedItemPositions();
		for (int _iIdx = 0; _iIdx < _arr.size(); _iIdx++) {
			if (_arr.valueAt(_iIdx))
			_result.add((double)_arr.keyAt(_iIdx));
		}
		return _result;
	}
	
	@Deprecated
	public float getDip(int _input) {
		return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, _input, getResources().getDisplayMetrics());
	}
	
	@Deprecated
	public int getDisplayWidthPixels() {
		return getResources().getDisplayMetrics().widthPixels;
	}
	
	@Deprecated
	public int getDisplayHeightPixels() {
		return getResources().getDisplayMetrics().heightPixels;
	}
}